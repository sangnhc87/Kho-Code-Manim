#set page(width: 17cm, height: 2.4cm, margin: 0pt, fill: none)
#set text(font: "Noto Serif", size: 28pt, fill: rgb("#FBBF24"))
#align(center + horizon)[$ 3^4 - 2^4 = 65 $]
