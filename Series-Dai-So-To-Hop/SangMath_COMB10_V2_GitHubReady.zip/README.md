# SANG MATH · COMB10 V2 — HOÁN VỊ CÁC PHẦN TỬ GIỐNG NHAU

Tập 10 của Series **Đại số tổ hợp Manim–Typst**. Kế thừa toàn bộ mã nguồn COMB01–COMB09 V2, GEO01 và chỉ bổ sung tập mới; những workflow cũ vẫn hoạt động.

## Sư phạm

- 48 nhịp / 8 chương, thời lượng nền khoảng 17 phút 37 giây (có tiếng có thể dài hơn).
- Hình bên trái, đề và suy luận bên phải; bài giải xuất hiện lần lượt theo thời gian.
- Thí dụ: AABC có 12 cách; MAMA có 6; BANANA có 60; ba A cùng khối 12; không hai A cạnh nhau 12; bắt đầu B hoặc kết thúc A có 34; AABBC không có AA: 18.
- Công thức n!/(k1! k2! ... kr!) và ký hiệu tổ hợp **C^(n)_(k)** theo yêu cầu (n trên, k dưới).

## Tệp chủ chốt

- `episodes/comb10_multiset_permutations.py` — Scene `COMB10`.
- `comb10_lesson_data.py` và `comb10_beats.json` — toán và 48 nhịp lời giảng.
- `scripts/prepare_comb10_v2.py` — biên dịch Typst, tạo giọng đọc và SRT.
- `scripts/qa_comb10_v2.py` — kiểm tra MP4 và trích tám ảnh chương.
- `.github/workflows/render-comb10-v2.yml` — workflow có hai chế độ preview/fullhd và voice on/off.
- `HUONG_DAN_RENDER_COMB10_V2.md` — hướng dẫn.

## Lệnh chạy cục bộ

```bash
python -m unittest discover -s tests -v
python scripts/prepare_comb10_v2.py --voice off
manim -ql -r 854,480 --fps 24 episodes/comb10_multiset_permutations.py COMB10
```

**Trạng thái:** mã Python/logic kiểm thử chạy trong môi trường soạn; Manim và Typst chưa sẵn tại máy soạn, do đó cần chạy workflow GitHub Actions và duyệt MP4 thật trước khi coi là hoàn thiện xuất bản.
