#set page(width: 17cm, height: 2.4cm, margin: 0pt, fill: none)
#set text(font: "Noto Serif", size: 28pt, fill: rgb("#22D3EE"))
#align(center + horizon)[$ (C_(k)^(2k))/(2) $]
