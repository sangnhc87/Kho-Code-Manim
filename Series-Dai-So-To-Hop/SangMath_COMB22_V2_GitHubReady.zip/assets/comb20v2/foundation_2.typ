#set page(width: 23cm, height: 2.4cm, margin: 0pt, fill: none)
#set text(font: "Noto Serif", size: 28pt, fill: rgb("#22D3EE"))
#align(center + horizon)[$ sum_(k=0)^n C^(n)_(k)=2^n $]
