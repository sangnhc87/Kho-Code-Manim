#set page(width: 23cm, height: 2.4cm, margin: 0pt, fill: none)
#set text(font: "Noto Serif", size: 28pt, fill: rgb("#22D3EE"))
#align(center + horizon)[$ integral_0^1 x^k(1-x) d x=frac(1,(k+1)(k+2)) $]
