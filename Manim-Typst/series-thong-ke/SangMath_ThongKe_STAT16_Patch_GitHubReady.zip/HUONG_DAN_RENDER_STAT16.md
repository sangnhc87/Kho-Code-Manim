# STAT16 – Nghịch lý Simpson trong thống kê

## 1. Đối tượng và các chuẩn video

- Toán phổ thông lớp 10–12, mở rộng tư duy phân tích dữ liệu; tất cả số liệu đều giả lập.
- 8 chương × 4 phân cảnh, tổng thời lượng nền 1216 giây (20 phút 16 giây).
- Giọng đọc nam Việt Nam qua Edge TTS: `vi-VN-NamMinhNeural`, tùy chọn `voice=on`.
- Footer **Thầy Nguyễn Văn Sang**; không hiện nhãn điều phối, bộ đếm trạng thái, tên công nghệ trong video.
- Layout hai cột cố định: trái là so sánh theo độ khó, cơ cấu, biểu đồ; phải là câu hỏi, lập luận và công thức.
- Hai bộ dữ liệu tổng hợp: `stat16/lesson.py`. Các tỉ lệ phải lấy từ tử số và mẫu số, **không** tạo bằng chuỗi gõ riêng.

## 2. Cài đặt và render GitHub Actions

Giải nén ZIP **trọn bộ** vào một repository mới, hoặc giải nén ZIP **patch STAT16** đè lên repository đã có STAT01–15. Commit và push. Vào tab **Actions**, mở **Render STAT16 - Nghich ly Simpson - Trong so va Dao chieu**, chọn **Run workflow**.

Chạy theo đúng thứ tự:

1. `quality=preview`, `voice=off`: chạy kiểm thử → tạo SVG Typst → tạo phụ đề → render khói cả 32 trạng thái → render MP4 854 × 480, 24 FPS → QA kích thước, thời lượng và 8 ảnh.
2. Xem tám ảnh trong `artifacts/stat16_qa` và toàn bộ MP4. Kiểm tra không có chữ đè, công thức lỗi, không có nhãn điều phối.
3. `voice=on`, trước tiên nên dùng `preview` để nghe toàn bộ lời giảng và kiểm tra đồng bộ tiếng/hình. Phải có kết nối mạng để Edge TTS hoạt động.
4. Sau khi duyệt cả hình và tiếng, chạy `quality=fullhd`, `voice=on` để xuất 1920 × 1080, 30 FPS.

Video, phụ đề và báo cáo nằm trong **Artifacts**, được lưu 7 ngày theo workflow mặc định. Render MP4 không thể kiểm chứng trong môi trường biên soạn nếu thiếu `manim` và `typst` thực tế.

## 3. Kiểm tra trên máy có Manim và Typst

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m compileall -q stat16 scripts
python scripts/check_stat16_states.py
python scripts/build_stat16_typst.py
python scripts/prepare_stat16.py --voice off
manim -ql -r 426,240 --fps 8 stat16/scene.py STAT16_SMOKE
manim -ql -r 854,480 --fps 24 stat16/scene.py STAT16
```

Sau khi có MP4, chạy:

```bash
python scripts/qa_stat16.py --video path/to/STAT16.mp4 --quality preview --voice off
```

## 4. Số liệu và đáp số để kiểm tra nhanh

| Nhóm độ khó | A đạt / tổng | B đạt / tổng |
|---|---:|---:|
| Dễ | 18/20 = 90% | 72/90 = 80% |
| Khó | 28/80 = 35% | 3/10 = 30% |
| **Gộp thực tế** | **46/100 = 46%** | **75/100 = 75%** |

**Cơ cấu:** A có 20% dễ, 80% khó; B có 90% dễ, 10% khó. **Chuẩn hóa 50/50:** A = 62,5%; B = 55%. **Dùng cơ cấu chung từ 200 lượt (55/45):** A = 65,25%; B = 57,5%. Bài tự luyện: A = 17/50 = 34%; B = 25/40 = 62,5%.

**Lưu ý thống kê:** số liệu mô tả kết quả quan sát giả lập, không chứng minh quan hệ nhân quả. Cơ cấu chuẩn hóa phải được nêu rõ, không được đánh đồng kết quả chuẩn hóa với tỉ lệ gộp thực tế.

## 5. Khắc phục lỗi build

- `ModuleNotFoundError: manim`: kiểm tra `requirements.txt` và các thư viện hệ thống cài bởi workflow.
- `typst: command not found`: kiểm tra `typst-community/setup-typst@v5` chạy thành công.
- `STAT16 formula SVG missing`: chạy `python scripts/build_stat16_typst.py`; không bỏ qua lỗi Typst.
- `VOICE ON but rendered MP4 is silent`: kiểm tra bước `prepare_stat16.py --voice on`, đường dẫn MP3 và kết nối tới dịch vụ TTS. Không xuất bản video im tiếng khi đã chọn giọng đọc.
- Sai nhãn 20% → 2%: hàm `as_pct()` đã có regression test để bảo vệ số 0 tận cùng và dấu thập phân kiểu tiếng Việt.
- Lỗi giao diện hoặc sai bản vẽ ở giữa video: xem `artifacts/stat16_qa/chapter_01.jpg` … `chapter_08.jpg` và log smoke-render.

**Quy trình nghiệm thu:** đọc kỹ log kiểm thử, duyệt 8 ảnh, xem và nghe cả MP4; số lượt kiểm thử Python không thay cho bước nghiệm thu hình–âm thanh thực tế.
