# STAT14 – ghi chú xây dựng

- Tập: **Bài toán thống kê tổng hợp và vận dụng thực tế**.
- Nguồn dữ liệu duy nhất: `stat14/lesson.py`.
- Scene: `STAT14`, smoke: `STAT14_SMOKE`.
- 8 chương × 4 trạng thái; nền 1.152 giây.
- Thống kê mô tả dùng mẫu số n; tứ phân vị theo trung vị của hai nửa dữ liệu.
- Các ví dụ **giả lập**, không suy diễn nhân quả hay cam kết tương lai.
- Giọng nam `vi-VN-NamMinhNeural`, footer `Thầy Nguyễn Văn Sang`, không nhãn kỹ thuật.
- Kịch bản và storyboard: `LOI_GIANG_STAT14.md` / `STORYBOARD_STAT14.md`.
- Ảnh tĩnh phác thảo: `preview/stat14/STAT14_storyboard_8_chapters.png`.
- Quy trình GitHub: `.github/workflows/render-stat14.yml`.
- Lệnh `python scripts/prepare_stat14.py --voice off` tạo timeline và SRT.
- **Giới hạn:** chưa thực hiện Manim/Typst thật trong container, phải nghiệm thu MP4 GitHub Actions.
