# HƯỚNG DẪN RENDER STAT14 – BÀI TOÁN THỐNG KÊ TỔNG HỢP

## 1. Quy tắc nghiệm thu bắt buộc
- Mã dựng hình: `stat14/scene.py`, Scene chính `STAT14`, Scene kiểm tra `STAT14_SMOKE`.
- Footer trong MP4 chỉ ghi **Thầy Nguyễn Văn Sang**. Không có bộ đếm bước dựng, chữ NHỊP, thông tin debug hoặc tên công nghệ.
- Nếu chọn giọng nói `on`, workflow dùng **giọng nam tiếng Việt** mặc định `vi-VN-NamMinhNeural` (giọng nam giới; không có bảo đảm là phương ngữ Nam Bộ).
- Hai cột cố định: biểu đồ bên trái, đề bài - diễn giải - công thức bên phải. Học sinh nhìn được đủ dữ kiện trước khi đáp án xuất hiện.
- Có tám chương, bốn phân cảnh/chương. Thời lượng nền 1.152 giây, tương đương **19 phút 12 giây**; giọng nói chậm hơn có thể kéo dài video.

## 2. Chạy GitHub Actions
1. Giải nén ZIP đầy đủ vào repository hoặc chép đè ZIP cập nhật lên repository vốn đã có STAT01–13.
2. Commit & push cả thư mục `.github/workflows/`, `stat14/`, `scripts/`, `typst/`, `tests/` và các tài liệu.
3. Vào **Actions → Render STAT14 - Bai toan van dung thuc te → Run workflow**.
4. Lần thứ nhất: chọn `quality=preview`, `voice=off`. Kiểm tra 8 khung QA và MP4.
5. Lần thứ hai: `quality=preview`, `voice=on`; **nghe thử** phát âm từ ngữ và kiểm tra khoảng dừng, phụ đề.
6. Cuối cùng: `quality=fullhd`, `voice=on` xuất 1920×1080, 30 FPS.
7. Vào phần Artifacts của job để tải MP4, SRT, `report.json`, 8 ảnh chụp kiểm tra.

## 3. Kiểm tra trước khi render
`Unit tests → Typst SVG → Prepare SRT/Voice → Smoke Manim 32 trạng thái → Render MP4 → ffprobe/ffmpeg QA`.
- Mọi bước đều **bắt buộc**, thất bại sẽ chặn bản Full HD.
- Thiếu SVG: xem bước **Compile 8 STAT14 Typst formulas**. Không được giả vờ xuất công thức thành công.
- Không có giọng: kiểm tra Internet GitHub, log edge-tts và tùy chọn `voice=on`; workflow sẽ báo lỗi thay vì im lặng.
- Video sai thời lượng: xem `stat14/runtime_plan.json` được tạo lại khi chạy workflow, không dùng kế hoạch cũ.
- Nếu lỗi `No module named manim`: kiểm tra bước `pip install -r requirements.txt`.
- Chữ bị đè: xem 8 khung QA từ MP4 thật; kiểm tra tỷ lệ ở cả 854×480 và 1920×1080.

## 4. Chạy cục bộ (máy đã cài Manim, Typst, FFmpeg)
```bash
python -m unittest discover -s tests -v
python scripts/check_stat14_states.py
python scripts/build_stat14_typst.py
python scripts/prepare_stat14.py --voice off
manim -ql -r 426,240 --fps 8 stat14/scene.py STAT14_SMOKE
manim -ql -r 854,480 --fps 24 stat14/scene.py STAT14
```

## 5. Cần duyệt thủ công trước khi dạy
- Các con số trên biểu đồ: hai quầy cùng trung bình 8, nhưng IQR 2 / 5 và phương sai 1,2 / 15.
- Tiêu chí tối đa 10 phút: 10/10 và 8/10; tối đa 5 phút: 0/10 và 3/10.
- Thay 10 thành 30: trung bình 8→10; IQR giữ 2; phương sai 1,2→45,2.
- Bảng điểm thô 40 quan sát trung bình 7,1, nhóm lại trung bình xấp xỉ 7,6.
- Gộp 10 em trung bình 8 với 30 em trung bình 6 cho kết quả **6,5**, không phải 7.
- Bài cuối: hai mẫu 8 quan sát cùng trung bình 8, IQR 1,5 / 4, phương sai 2 / 11,5.
- Không diễn giải tỉ lệ của 10 lần khảo sát là xác suất chắc chắn cho người dùng tương lai.

## 6. Điều đã được kiểm thử và giới hạn
Trong môi trường xây dựng mã ở đây: đã kiểm thử Python, cú pháp, 32 trạng thái **mô phỏng**, timeline và tính toàn vẹn ZIP. Chưa có Manim/Typst cài sẵn để render MP4 thật. Bước smoke-render và biên dịch SVG phải được kiểm tra bằng GitHub Actions; việc chạy đạt không thay thế khâu nhìn - nghe nghiệm thu sư phạm.
