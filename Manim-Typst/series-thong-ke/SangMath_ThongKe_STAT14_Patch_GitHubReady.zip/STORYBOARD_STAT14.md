# STAT14 – BÀI TOÁN THỐNG KÊ TỔNG HỢP VÀ VẬN DỤNG THỰC TẾ

**Khung hình:** trái là dữ liệu, biểu đồ chính xác; phải là đề bài, luận điểm và công thức xuất hiện theo tiến trình.
**Footer trong video:** Thầy Nguyễn Văn Sang.
**Nội bộ:** mỗi chương bốn trạng thái; không xuất số trạng thái hoặc thông tin điều phối trên video.
**Công thức:** phương sai chia n; tứ phân vị tính theo trung vị của nửa dưới và nửa trên dữ liệu.
**Quy trình:** mở đề → quan sát → lập luận → kết luận, không bật đáp án trước.

## Chương 01. BÀI TOÁN THỰC TẾ: CHỌN QUẦY PHỤC VỤ

**Mô hình động:** Hai dãy chấm thời gian chờ A/B trên chung trục; thêm đường trung bình 8 phút.

### Hai quầy phục vụ, một câu hỏi
**Kiến thức:** Cùng trung bình chưa chắc cùng chất lượng phục vụ.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Một thư viện khảo sát thời gian chờ của mười lượt khách tại mỗi quầy A và B. Bảng thời gian được đo bằng phút, đã sắp theo thứ tự tăng dần để tiện theo dõi. Nếu chỉ có một chỉ số để chọn quầy, em sẽ xem số trung bình hay thời gian lâu nhất? Trước hết hãy đọc dữ liệu và đặt tiêu chí rõ ràng.

### Đặt hai dãy thời gian cạnh nhau
**Kiến thức:** Quầy A tập trung quanh tám phút; quầy B trải rộng.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Ở quầy A, các quan sát từ sáu đến mười phút, nhiều lần bằng tám. Ở quầy B, khách nhanh nhất đợi hai phút, còn có khách phải đợi đến mười lăm phút. Chúng ta vẽ các điểm trên cùng trục phút, không tùy ý thay đổi tỉ lệ trục để làm sự khác biệt trông lớn hơn hoặc nhỏ đi.

### Tính trung bình và trung vị
**Kiến thức:** Cả hai quầy cùng trung bình 8 phút, trung vị 8 phút.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Tổng thời gian chờ tại mỗi quầy đều bằng tám mươi phút. Chia cho mười lượt khảo sát, cả hai quầy cùng trung bình tám phút. Giá trị giữa, tức trung vị, của mỗi dãy cũng bằng tám. Hai con số trung tâm đều giống nhau, nhưng điều đó chưa cho phép ta nói rằng trải nghiệm của mọi lượt khách là giống nhau.

### Nêu mục tiêu trước khi tính
**Kiến thức:** Đồng đều, nhanh nhất hay đúng hạn là ba tiêu chí khác nhau.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Nếu quản lý muốn thời gian phục vụ ổn định, cần xem độ phân tán. Nếu khách mong có cơ hội được phục vụ cực nhanh, hãy đếm những lượt chờ không quá năm phút. Nếu thư viện cam kết chờ không quá mười phút, ta phải đếm lượt đạt cam kết. Bài toán vận dụng bắt đầu bằng việc xác định rõ điều cần đánh giá.

## Chương 02. PHÂN TÍCH ĐỘ PHÂN TÁN

**Mô hình động:** Hai biểu đồ hộp đồng tỉ lệ; hiện các mốc Q1 Q3, sau đó sd A/B.

### So sánh khoảng biến thiên
**Kiến thức:** A: R=4 phút; B: R=13 phút.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Khoảng biến thiên bằng thời gian lớn nhất trừ thời gian nhỏ nhất. Quầy A có khoảng biến thiên mười trừ sáu, bằng bốn phút. Quầy B có khoảng biến thiên mười lăm trừ hai, bằng mười ba phút. Đây là một tín hiệu quầy B biến động mạnh hơn, nhưng khoảng biến thiên chỉ dựa vào hai giá trị ở hai đầu.

### Dùng biểu đồ hộp cùng một trục
**Kiến thức:** A có Q1=7, Q3=9; B có Q1=5, Q3=10.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Sử dụng quy ước tứ phân vị lấy trung vị mỗi nửa dữ liệu. Với quầy A, tứ phân vị thứ nhất bằng bảy và thứ ba bằng chín, nên hộp dài hai phút. Với B, hai mốc đó là năm và mười, hộp dài năm phút. Hãy quan sát hai hộp đặt trên cùng trục, tuyệt đối không kéo co giãn một hình để gây hiểu nhầm.

### Phương sai và độ lệch chuẩn
**Kiến thức:** A: s²=1,2; B: s²=15, đơn vị bình phương phút.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Cả hai quầy cùng trung bình tám phút. Lấy từng quan sát trừ tám, bình phương rồi lấy trung bình cộng, ta thu được phương sai của A bằng một phẩy hai, còn B bằng mười lăm. Công thức đang dùng mẫu số n trong thống kê mô tả. Đơn vị của phương sai là phút bình phương, không phải phút.

### Kết luận đúng tiêu chí đồng đều
**Kiến thức:** s(A)≈1,095 phút; s(B)≈3,873 phút.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Lấy căn bậc hai để đưa về đơn vị phút, độ lệch chuẩn của A xấp xỉ một phẩy không chín năm phút, của B xấp xỉ ba phẩy tám bảy ba phút. Trong mười lượt đã khảo sát, quầy A đồng đều hơn theo độ lệch chuẩn và khoảng tứ phân vị. Đây là kết luận mô tả mẫu quan sát, chưa phải bảo đảm cho những ngày tiếp theo.

## Chương 03. ĐỔI MỤC TIÊU, ĐỔI QUYẾT ĐỊNH

**Mô hình động:** Hai hàng 10 ô đổi màu theo tiêu chí chờ tối đa 10 hoặc 5 phút.

### Đặt mục tiêu không quá 10 phút
**Kiến thức:** A: 10/10; B: 8/10 lượt đạt.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Thư viện đưa ra cam kết thời gian chờ không quá mười phút. Đếm trực tiếp từ dãy số, cả mười lượt ở quầy A đều đạt, còn quầy B chỉ có tám trong mười lượt đạt. Như vậy theo tiêu chí duy trì cam kết trong mẫu quan sát, A tốt hơn B. Ta không cần dùng trung bình hay độ lệch chuẩn để thay cho phép đếm đúng ngưỡng.

### Đặt mục tiêu được phục vụ rất nhanh
**Kiến thức:** Không quá 5 phút: A có 0 lượt, B có 3 lượt.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Một vị khách lại quan tâm đến những lần chờ rất ngắn, chẳng hạn không quá năm phút. Quầy A không có lượt nào đạt, nhưng quầy B có ba lượt: hai, ba và năm phút. Với tiêu chí này, quầy B có nhiều lượt nhanh hơn trong mẫu. Kết luận thay đổi do mục tiêu thay đổi, không phải vì dữ liệu bị đổi.

### Hai mục tiêu, hai câu trả lời
**Kiến thức:** Không tồn tại một quầy luôn tốt hơn ở mọi tiêu chí.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Đặt hai ngưỡng năm phút và mười phút lên cùng biểu đồ. Ở ngưỡng năm, B có ba lượt đạt so với không lượt của A; ở ngưỡng mười, A có mười lượt so với tám lượt của B. Việc chọn chỉ số đúng quan trọng hơn tìm ra một câu trả lời nghe có vẻ tuyệt đối. Hãy luôn nói rõ mình đang tối ưu điều gì.

### Không biến tần suất mẫu thành lời hứa
**Kiến thức:** Tỉ lệ quan sát không tự động là xác suất tương lai.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Mười lượt được quan sát ở từng quầy chưa đủ để khẳng định trong tương lai khách sẽ luôn đợi không quá mười phút tại A. Các con số mười trên mười và tám trên mười là tần suất trong dữ liệu đang xét. Muốn ước lượng cho thời gian dài hơn, cần cách lấy mẫu phù hợp, thêm quan sát và xem thời điểm đông khách.

## Chương 04. ĐIỂM BẤT THƯỜNG VÀ CHỈ SỐ BỀN VỮNG

**Mô hình động:** Một chấm 10 phút dịch đến 30 phút; đối chiếu trung bình, trung vị và phương sai.

### Khi một lượt chờ thành 30 phút
**Kiến thức:** Thay đúng một giá trị 10 bằng 30.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Giả sử trong dữ liệu quầy A, một lượt vốn chờ mười phút được thay bằng một lượt phải chờ ba mươi phút. Mọi lượt còn lại được giữ nguyên. Trên hình, chỉ một điểm dịch về bên phải. Ta không bỏ qua giá trị này hay chỉnh sửa dữ liệu để có kết luận đẹp, mà thử xem mỗi đại lượng thống kê phản ứng như thế nào.

### Số trung bình nhạy với ngoại lệ
**Kiến thức:** Trung bình từ 8 lên 10 phút.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Ban đầu tổng thời gian của A là tám mươi phút. Khi thay mười bằng ba mươi, tổng tăng thêm hai mươi thành một trăm phút; trung bình của mười lượt thành mười phút. Số trung bình tăng hai phút, dù chín lượt khác không hề thay đổi. Đây là lý do cần kiểm tra các giá trị rất lớn trước khi dùng trung bình để mô tả trải nghiệm điển hình.

### Trung vị và IQR vẫn ổn định
**Kiến thức:** Trung vị 8 phút, IQR 2 phút không đổi.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Sắp xếp dãy sau thay đổi, hai giá trị giữa vẫn là tám nên trung vị không đổi. Trung vị nửa dưới vẫn bằng bảy và nửa trên vẫn bằng chín, do đó khoảng tứ phân vị cũng giữ nguyên hai phút. Điều này không có nghĩa trung vị và IQR không bao giờ thay đổi, mà cho thấy chúng ít nhạy hơn trong phép thay một giá trị cụ thể này.

### Độ lệch chuẩn tăng rất mạnh
**Kiến thức:** Phương sai tăng từ 1,2 lên 45,2.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Tính lại bình phương độ lệch quanh trung bình mới là mười phút, phương sai của A sau thay đổi bằng bốn mươi lăm phẩy hai. Giá trị này lớn hơn rất nhiều so với một phẩy hai ban đầu, vì khoảng cách tới ba mươi được bình phương. Khi báo cáo, hãy ghi cả trung vị, IQR và các số đo nhạy với ngoại lệ để không che khuất đặc điểm dữ liệu.

## Chương 05. DỮ LIỆU GỐC, GHÉP NHÓM VÀ SAI SỐ

**Mô hình động:** Các điểm gốc → histogram ghép nhóm, phân biệt trung bình 7,1 với 7,6.

### Đọc lại 40 điểm gốc
**Kiến thức:** Dữ liệu gốc có trung bình 7,1.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Chuyển sang bộ bốn mươi điểm kiểm tra quen thuộc của Series. Nếu giữ đủ từng điểm gốc, chúng ta tính được trung bình chính xác bằng bảy phẩy một. Khi đã biết dữ liệu thô, phép tính này không cần giả sử mỗi quan sát nằm ở trung điểm lớp. Bây giờ thử thay bảng thô bằng bảng ghép nhóm để thấy thông tin nào bị mất.

### Ước lượng bằng trung điểm lớp
**Kiến thức:** Trung bình ghép nhóm 7,6, không phải 7,1.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Bốn lớp điểm có trung điểm năm, bảy, chín và mười một; tần số tương ứng sáu, mười tám, mười bốn và hai. Lấy tổng các tích trung điểm với tần số rồi chia bốn mươi, ta được bảy phẩy sáu. Kết quả này không sai: nó là giá trị ước lượng sau khi thay mọi điểm trong lớp bằng trung điểm.

### Phương sai cũng chỉ là ước lượng
**Kiến thức:** Gốc: 2,29; từ trung điểm lớp: 2,44.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Tính trên bốn mươi điểm gốc, phương sai là hai phẩy hai chín. Nếu chỉ dùng trung điểm của các lớp, phương sai ghép nhóm bằng hai phẩy bốn bốn. Chênh lệch không do đổi công thức chia n, mà do phép đại diện các giá trị trong lớp. Trong bài giải, phải ghi rõ đại lượng nào tính từ dữ liệu thô và đại lượng nào ước lượng từ bảng ghép.

### Không thể khôi phục chính xác
**Kiến thức:** Bảng tần số không cho biết từng điểm bên trong lớp.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Một bảng ghép nhóm có thể được tạo ra từ nhiều dãy số khác nhau. Khi chỉ biết sáu quan sát ở lớp từ bốn đến dưới sáu, ta không biết từng quan sát cụ thể. Do đó không được khẳng định chắc chắn trung bình gốc bằng trung bình trung điểm lớp. Quy tắc thực hành là nêu nguồn dữ liệu, đánh dấu rõ ước lượng và tránh suy luận quá mức.

## Chương 06. GỘP HAI NHÓM: TRỌNG SỐ VÀ QUY MÔ

**Mô hình động:** Hai nhóm lần lượt 10 và 30 học sinh: số ô đúng với quy mô.

### Hai nhóm học sinh quy mô khác nhau
**Kiến thức:** Nhóm A: 10 em, trung bình 8; B: 30 em, trung bình 6.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Một trường cần tính trung bình điểm kiểm tra của hai nhóm học sinh. Nhóm A có mười em với trung bình tám, nhóm B có ba mươi em với trung bình sáu. Vì số học sinh khác nhau, ta không thể tùy tiện lấy tám cộng sáu rồi chia hai để coi đó là trung bình chung của bốn mươi em.

### Vì sao trung bình của hai số là sai
**Kiến thức:** Lấy (8+6)/2=7 bỏ qua quy mô nhóm.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Nếu lấy trung bình của hai mức trung bình, ta thu được bảy. Cách này ngầm coi hai nhóm có trọng số bằng nhau, trong khi nhóm B có số học sinh gấp ba A. Muốn tìm trung bình cho toàn bộ bốn mươi em, phải khôi phục tổng điểm từng nhóm bằng cỡ mẫu nhân trung bình rồi chia theo tổng số học sinh.

### Tính trung bình có trọng số
**Kiến thức:** (10×8+30×6)/40 = 6,5.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Tổng điểm nhóm A là tám mươi; nhóm B là một trăm tám mươi. Tổng cộng hai trăm sáu mươi điểm cho bốn mươi học sinh. Chia hai trăm sáu mươi cho bốn mươi, trung bình chung đúng là sáu phẩy năm. Trên biểu đồ, khối nhóm ba mươi học sinh phải dài gấp ba khối mười học sinh, để trực quan khớp số liệu.

### Quy tắc khi gộp nhiều nhóm
**Kiến thức:** Trọng số chính là số quan sát của từng nhóm.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Với nhiều nhóm, công thức trung bình chung là tổng cỡ mẫu nhân trung bình của từng nhóm, chia tổng cỡ mẫu. Mỗi học sinh chỉ được tính đúng một lần. Nếu bảng chỉ cho phần trăm, phải kiểm tra các phần trăm cùng cơ sở. Đây là kỹ năng đặc biệt quan trọng khi tổng hợp báo cáo giữa các lớp hoặc các đợt khảo sát không cùng quy mô.

## Chương 07. BÁO CÁO THỐNG KÊ CÓ TRÁCH NHIỆM

**Mô hình động:** Bốn nguyên tắc báo cáo, hiện dần từng ô.

### Bước một: nêu dữ liệu và phạm vi
**Kiến thức:** Dữ liệu được ghi theo phút, mẫu chỉ gồm 10 lượt/quầy.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Một báo cáo đáng tin cậy cần nói đang đo đại lượng gì, đơn vị nào và khảo sát được bao nhiêu lượt. Trong tình huống này, chúng ta có mười thời gian chờ được ghi ở mỗi quầy, đơn vị là phút. Số liệu giả lập này chỉ dùng để học cách phân tích, không đại diện cho hoạt động của một thư viện thật.

### Bước hai: chọn thước đo theo mục tiêu
**Kiến thức:** Ổn định dùng độ phân tán; đúng hạn dùng tỉ lệ đạt ngưỡng.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Đừng lập báo cáo chỉ bằng một bảng toàn công thức. Nếu cần xét sự đồng đều, hãy so sánh độ lệch chuẩn và IQR trên cùng đơn vị. Nếu cần kiểm tra cam kết, hãy đếm số lượt không quá giới hạn. Nếu dữ liệu có ngoại lệ, cân nhắc trung vị và IQR bên cạnh trung bình. Thước đo phải phục vụ câu hỏi cần trả lời.

### Bước ba: kiểm tra giả định và cách đo
**Kiến thức:** Không suy nhân quả từ vài quan sát mô tả.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Hai quầy có thể được quan sát vào những khung giờ khác nhau, khi lượng khách khác nhau hoặc quy trình phục vụ khác nhau. Bản thống kê mô tả không chứng minh quầy nào vận hành tốt hơn trong mọi điều kiện. Muốn tìm nguyên nhân, cần một thiết kế thu thập dữ liệu phù hợp, kiểm soát các yếu tố khác và quan sát đủ rộng.

### Viết kết luận có điều kiện
**Kiến thức:** Nói trong mẫu này, theo tiêu chí này.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Một kết luận gọn và chặt chẽ là: trong mười lượt khảo sát tại mỗi quầy, hai trung bình cùng bằng tám phút; A có độ lệch chuẩn thấp hơn và mười trên mười lượt đạt ngưỡng mười phút, trong khi B có tám. Nhưng B có ba lượt chờ không quá năm phút còn A không có. Mọi nhận xét cần gắn rõ tiêu chí.

## Chương 08. THỬ THÁCH TỔNG HỢP CÓ LỜI GIẢI

**Mô hình động:** Hai dãy thời gian C/D (8 giá trị): tự tính rồi mới xuất lời giải.

### Bài tập: hai phương án giao hàng
**Kiến thức:** Hai dãy 8 thời gian chờ; cần chọn phương án ổn định.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Đến thử thách cuối, hãy xem hai phương án giao hàng giả lập C và D, mỗi phương án có tám thời gian thực hiện tính bằng phút. Nhiệm vụ đầu tiên là kiểm tra tổng và trung bình; sau đó tìm trung vị, khoảng biến thiên, tứ phân vị và phương sai. Trước khi hiện lời giải, em nên tự ghi dự đoán phương án nào ổn định hơn.

### Tính tâm và các cực trị
**Kiến thức:** C và D cùng trung bình 8, trung vị 8.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Tổng thời gian mỗi phương án đều bằng sáu mươi bốn phút, vì thế trung bình đều bằng tám. Trung vị của cả hai cũng bằng tám. Tuy nhiên C trải từ sáu đến mười một, còn D trải từ hai đến mười bốn. Khoảng biến thiên của C là năm và của D là mười hai. Chỉ riêng điều đó đã cho thấy sự khác biệt đáng quan sát.

### Giải thích IQR và phương sai
**Kiến thức:** C: IQR=1,5, s²=2; D: IQR=4, s²=11,5.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Theo cách lấy trung vị của mỗi nửa, phương án C có tứ phân vị thứ nhất là bảy và thứ ba là tám phẩy năm, khoảng tứ phân vị một phẩy năm. Với D, hai mốc lần lượt là sáu và mười, IQR bằng bốn. Tính bình phương độ lệch rồi chia tám, phương sai của C bằng hai, còn D bằng mười một phẩy năm.

### Lựa chọn và viết kết luận hoàn chỉnh
**Kiến thức:** C ổn định hơn trong mẫu; nêu rõ tiêu chí.
**Diễn tiến:** dữ kiện xuất hiện trước, bước giải sau; không hiển thị số thứ tự kỹ thuật.
**Đọc:** Theo tiêu chí ổn định trong tám lần ghi nhận, phương án C có cả IQR và phương sai nhỏ hơn nên là lựa chọn phù hợp hơn. Nhưng nếu mục tiêu là tìm một số lần giao cực nhanh dưới năm phút, D có những trường hợp mà C không có. Bài học kết thúc bằng quy trình: đọc đúng dữ liệu, chọn đúng chỉ số, tính đúng và phát biểu kết luận có giới hạn.

