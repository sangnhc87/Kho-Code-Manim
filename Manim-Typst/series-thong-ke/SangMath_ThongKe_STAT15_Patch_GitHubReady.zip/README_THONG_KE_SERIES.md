# Tình trạng Series: 15/18 tập có mã nguồn

**STAT15 – Những biểu đồ thống kê gây hiểu nhầm:** 8 chương, 32 phân cảnh; cắt trục, đổi tỉ lệ, trục thời gian, biểu tượng, mẫu số, chọn khung thời gian, histogram độ rộng khác nhau và bài cuối.

Cài đặt video: giọng nam tiếng Việt (`vi-VN-NamMinhNeural`), footer chính xác “Thầy Nguyễn Văn Sang”; không hiển thị bộ đếm hoặc nhãn công nghệ. Để nghiệm thu cần render Manim, biên dịch Typst và duyệt bản MP4 thật trên GitHub.

# SANGMATH – THỐNG KÊ TRỰC QUAN LỚP 10–11–12

**Tiến độ mã nguồn: 14/18 tập.** Sản phẩm gồm nguồn bài giảng, hoạt hình, phụ đề, thiết kế storyboard và workflow xuất video trên GitHub Actions.

| Tập | Bài học | Trạng thái |
|---|---|---|
| 01 | Thu thập và biểu diễn dữ liệu | Có mã nguồn |
| 02 | Các loại biểu đồ thống kê | Có mã nguồn |
| 03 | Trung bình, trung vị và mốt của dữ liệu gốc | Có mã nguồn |
| 04 | Tứ phân vị của mẫu dữ liệu gốc | Có mã nguồn |
| 05 | Khoảng biến thiên, IQR và biểu đồ hộp | Có mã nguồn |
| 06 | Phương sai và độ lệch chuẩn | Có mã nguồn |
| 07 | Mẫu số liệu ghép nhóm, bảng tần số | Có mã nguồn |
| 08 | Số trung bình và mốt ghép nhóm | Có mã nguồn |
| 09 | Trung vị mẫu ghép nhóm | Có mã nguồn |
| 10 | Tứ phân vị mẫu ghép nhóm | Có mã nguồn |
| 11 | Khoảng biến thiên và IQR ghép nhóm | Có mã nguồn |
| 12 | Phương sai và độ lệch chuẩn ghép nhóm | Có mã nguồn |
| 13 | **So sánh hai mẫu số liệu** | **Mã nguồn mới** |
| 14 | Bài toán thống kê tổng hợp và vận dụng cao | Kế hoạch |
| 15 | Biểu đồ dễ gây hiểu nhầm | Kế hoạch |
| 16 | Nghịch lý Simpson | Kế hoạch |
| 17 | Tương quan, hồi quy tuyến tính | Kế hoạch |
| 18 | Lấy mẫu, thiên lệch và mô phỏng | Kế hoạch |

**STAT13:** so sánh nhiều chỉ số cùng lúc, phân biệt “cùng trung bình” và “cùng phân bố”, quan tâm tỉ lệ đạt chuẩn theo mục tiêu; dữ liệu minh họa giả lập. Xem `HUONG_DAN_RENDER_STAT13.md`.

Quy tắc xuyên suốt: lời đọc nam tiếng Việt, footer **Thầy Nguyễn Văn Sang**, không đưa số nhịp điều phối hoặc tên công nghệ vào khung hình. Khi GitHub Actions render xong, cần duyệt hình và nghe tiếng thật.


## STAT14 – Bài toán thống kê tổng hợp và vận dụng thực tế

Mã và workflow: `stat14/`, `.github/workflows/render-stat14.yml`.
Giáo án 8 chương × 4 phân cảnh; 19:12 nền; giọng nam tiếng Việt; footer **Thầy Nguyễn Văn Sang**.
Bài tổng hợp lựa chọn tiêu chí, dữ liệu ngoại lệ, bảng ghép nhóm, trung bình trọng số và báo cáo có trách nhiệm.
Storyboard: `preview/stat14/STAT14_storyboard_8_chapters.png`.
**Lưu ý:** cần nghiệm thu bằng Manim/Typst thật trên GitHub Actions trước khi sử dụng.
