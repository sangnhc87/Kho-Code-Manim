# SangMath Thống kê – mã nguồn 15 bài học

**Tình trạng:** 15/18 tập có mã nguồn và workflow GitHub Actions. Để nghiệm thu bài giảng, phải render MP4 thật và xem lại hình ảnh, tiếng đọc trước khi phát hành.

## Tập mới: STAT15 – Những biểu đồ thống kê gây hiểu nhầm

**Nội dung:** hai cột 80/100 và trục cắt 75; đổi thang tung trên biểu đồ đường; các mốc năm cách không đều; biểu tượng phóng đại; số lượng so với tỉ lệ; cắt ngắn thời gian; histogram lớp rộng không đều; bài thám tử đồ thị với 62%/68%.

**Cấu trúc:** 8 chương × 4 phân cảnh = 32 cảnh, 19 phút 12 giây nền; giọng nam Việt tùy chọn và phụ đề SRT.

- Nguồn dữ liệu và lời đọc: `stat15/lesson.py`, scene `stat15/scene.py` (`STAT15`, `STAT15_SMOKE`).
- Công thức: `typst/stat15/` → `assets/stat15_formulas/` tạo trong Actions.
- Script: `scripts/build_stat15_typst.py`, `scripts/prepare_stat15.py`, `scripts/check_stat15_states.py`, `scripts/qa_stat15.py`.
- Kiểm thử: `tests/test_stat15.py`; workflow `.github/workflows/render-stat15.yml`.
- Tài liệu: `LOI_GIANG_STAT15.md`, `STORYBOARD_STAT15.md`, `HUONG_DAN_RENDER_STAT15.md`.
- Bản thiết kế: `preview/stat15/STAT15_storyboard_8_chapters.png`.

**Chuẩn lên lớp:** footer “Thầy Nguyễn Văn Sang”, không bộ đếm/trạng thái điều phối, không tên công nghệ trong video. Kiểm tra MP4 và giọng đọc thật trên GitHub trước khi dùng.

## Tập mới: STAT14 – Bài toán thống kê tổng hợp và vận dụng thực tế

**Nội dung:** quyết định theo mục tiêu từ hai dãy thời gian chờ; so sánh trung bình, trung vị, IQR, độ lệch chuẩn; ảnh hưởng của ngoại lệ; dữ liệu thô so với ghép nhóm; trung bình gộp đúng trọng số; báo cáo có giới hạn và bài tập tổng hợp.

**Giáo án:** 8 chương × 4 phân cảnh, 19 phút 12 giây nền, giọng nam Việt tùy chọn và phụ đề SRT.

- `stat14/lesson.py`, `stat14/scene.py` (`STAT14`, `STAT14_SMOKE`).
- `scripts/build_stat14_typst.py`, `scripts/check_stat14_states.py`, `scripts/prepare_stat14.py`, `scripts/qa_stat14.py`.
- `.github/workflows/render-stat14.yml`, `tests/test_stat14.py`.
- `LOI_GIANG_STAT14.md`, `STORYBOARD_STAT14.md`, `HUONG_DAN_RENDER_STAT14.md`.
- `preview/stat14/STAT14_storyboard_8_chapters.png` (thiết kế, không phải khung hình render).

**Trình bày:** footer `Thầy Nguyễn Văn Sang`, không số trạng thái hoặc nhãn điều phối. **Quan trọng:** phải render và nghiệm thu hình-tiếng thật trên GitHub Actions trước khi dạy.

## Tập trước (STAT13) và các tập trước nữa

### STAT13 – So sánh hai mẫu số liệu

**Kiến thức:** so sánh trung bình, trung vị, mốt, khoảng biến thiên, Q1–Q3, IQR, phương sai và độ lệch chuẩn; chọn chỉ số theo mục tiêu; lưu ý khác biệt giữa số liệu thô và ghép nhóm. Ví dụ giả lập A/B có cùng trung bình 7 nhưng phương sai 1,2 và 5,4.

**Cấu trúc:** 8 chương × 4 phân cảnh, có thuyết minh tiếng Việt, phụ đề SRT, công thức dựng qua Typst, 8 ảnh QA và bước smoke-render.

- Mã nguồn: `stat13/lesson.py`, `stat13/scene.py` (`STAT13` và `STAT13_SMOKE`).
- Typst: `typst/stat13/*.typ` → `assets/stat13_formulas/*.svg` (biên dịch trong Actions).
- Tạo lời đọc/phụ đề: `scripts/prepare_stat13.py` → `stat13/runtime_plan.json`, `STAT13_vi.srt`.
- GitHub: `.github/workflows/render-stat13.yml`.
- Kiểm thử: `python -m unittest discover -s tests -v`, `python scripts/check_stat13_states.py`.
- Lời giảng: `LOI_GIANG_STAT13.md`; storyboard: `STORYBOARD_STAT13.md`.
- Ảnh phác thảo: `preview/stat13/STAT13_storyboard_8_chapters.png`.
- Chi tiết: `HUONG_DAN_RENDER_STAT13.md`.

**Tiêu chuẩn bài giảng:** footer hiển thị **Thầy Nguyễn Văn Sang**, không có bộ đếm nhịp hoặc tên công nghệ trên màn hình. Giọng nam Việt `vi-VN-NamMinhNeural` nếu bật TTS. Bản preview dùng `voice=off`; bản có tiếng cần được nghe và duyệt.

## Các tập trước

Các tập STAT01–STAT13 và workflow riêng được giữ trong các thư mục `stat01/` đến `stat12/`; tài liệu của từng tập nằm ở `LOI_GIANG_STATXX.md`, `STORYBOARD_STATXX.md` và `HUONG_DAN_RENDER_STATXX.md` (riêng tập đầu có hướng dẫn chung).

**Quan trọng:** việc kiểm thử mô phỏng chỉ đảm bảo logic Python, không chứng minh bản MP4 thật được render đúng. GitHub Actions phải biên dịch công thức và chạy Manim trước khi duyệt.
