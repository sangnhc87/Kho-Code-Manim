# HƯỚNG DẪN RENDER VÀ NGHIỆM THU STAT15

## Tập học
**STAT15 – Những biểu đồ thống kê gây hiểu nhầm**: 8 chương, 32 phân cảnh, nền 1152 giây = **19 phút 12 giây**. Phần lời đọc có thể khiến tổng thời lượng dài hơn 19:12 nếu TTS dài hơn thời lượng nền của phân cảnh.

**Chuẩn hiển thị bắt buộc:** footer chính xác `Thầy Nguyễn Văn Sang`; không có bộ đếm phân cảnh/nhịp, không có chữ debug hoặc tên công nghệ. Phần mềm dựng hình không xuất hiện trong nội dung hướng tới học sinh.

**Giọng đọc nam:** `vi-VN-NamMinhNeural` (nam giới, không mặc định có phương ngữ Nam Bộ); muốn kiểm tra hình riêng, dùng `voice=off`.

## Cập nhật dự án
- Nếu đã có mã nguồn STAT01–14: giải nén gói `SangMath_ThongKe_STAT15_Patch_GitHubReady.zip`, chép đè vào thư mục gốc repository, commit và push **bao gồm thư mục `.github` ẩn**.
- Nếu khởi tạo repository mới: giải nén `SangMath_ThongKe_STAT01_STAT15_GitHubReady.zip` rồi commit/push cả thư mục.
- Không chép riêng `stat15/scene.py`: tệp phụ thuộc `stat15/lesson.py`, nguồn công thức `typst/stat15/`, `scripts/` và workflow phải đi kèm.

## Chạy GitHub Actions
1. Mở **Actions → Render STAT15 - Bieu do thong ke gay hieu nham → Run workflow**.
2. Chạy `quality=preview`, `voice=off` trước; workflow kiểm thử Python, tạo SVG Typst, chuẩn bị timeline và phụ đề, **smoke-render Manim thật tất cả 32 phân cảnh**.
3. Kiểm tra MP4 854×480, 8 ảnh kiểm tra chương và log kết quả; đánh giá nhãn trục, vị trí số, công thức và mức rõ chữ.
4. Chạy lại `quality=preview`, `voice=on` để nghe giọng nam; đặc biệt kiểm tra phát âm "trục tung", "điểm phần trăm", "mật độ tần số".
5. Chỉ khi hình và âm thanh đạt yêu cầu mới chạy `quality=fullhd`, `voice=on` để xuất 1920×1080 @ 30 FPS.
6. Tải video và báo cáo từ **Artifacts**; không coi `source checks` là chứng cứ đã có MP4 hợp lệ.

## Chạy trực tiếp ở môi trường có Manim, Typst và FFmpeg
```bash
python -m unittest discover -s tests -v
python scripts/check_stat15_states.py
python scripts/build_stat15_typst.py
python scripts/prepare_stat15.py --voice off
manim -ql -r 426,240 --fps 8 stat15/scene.py STAT15_SMOKE
manim -ql -r 854,480 --fps 24 stat15/scene.py STAT15
```

## Bảng đối chiếu phải nhìn tận mắt trên bản MP4
| Chương | Dữ liệu cần đúng | Cảnh cần xem |
|---|---|---|
| 01 | Giá trị 80 và 100, gốc 75 tạo tỉ lệ chiều cao 5; gốc 0 cho 100/80=1,25 | Hai cột phải giữ nguyên nhãn số thật |
| 02 | 40,44,52,56; thang tung hẹp so với 0–100 | Trục có ghi rõ mốc trên và dưới |
| 03 | 2020–2021 cách 1 năm; 2021–2024 cách 3 năm | Các điểm có khoảng cách đúng khi trục là thời gian thật |
| 04 | Số lượng 20:40 = 1:2; bán kính ×2 làm diện tích ×4; đúng phải ×√2 | Hai hình tròn có tỉ số bán kính chính xác |
| 05 | A 18/30=60%; B 24/80=30% | Không nhầm tần số với tỉ lệ |
| 06 | 2022→2023: -10%; 2020→2025: +28% | Có đủ cả sáu mốc trong hình toàn kỳ |
| 07 | Bề rộng lớp 2,4,1,3; mật độ 4,3,6,3; tổng diện tích 35 | Các cột liền nhau đúng tỉ lệ bề rộng và chiều cao |
| 08 | 62%,68%; chênh 6 điểm phần trăm; tăng tương đối ≈9,68% | Cột đổi từ gốc 60 sang 0 nhưng giá trị gốc không bị thay đổi |

## Xử lý lỗi thường gặp
- **Typst compile failed / missing SVG:** xem bước `Compile 8 STAT15 Typst formulas`; các tệp nguồn ở `typst/stat15/`.
- **Lỗi phát âm hoặc thiếu tiếng:** log `Prepare narration`, kiểm tra mạng khi edge-tts tạo 32 tệp MP3; nếu `voice=on` mà không có luồng tiếng, QA phải thất bại.
- **Tràn chữ / SVG ngoài vùng:** đọc 8 ảnh JPEG trích từ MP4 và kiểm tra cả bản Full HD. Mô phỏng Python không thể phát hiện mọi vấn đề bố cục trên Manim thật.
- **Sai thời lượng:** `stat15/runtime_plan.json` được tạo lại mỗi lần chạy; file trong ZIP là kế hoạch **voice=off** làm ví dụ.
- **Workflow không xuất hiện:** đảm bảo tệp `.github/workflows/render-stat15.yml` đã được commit và repository cho phép chạy Actions.

## Giới hạn kiểm thử
Đã kiểm tra nội dung, kiểm thử toán học, mock trạng thái, cú pháp, timeline và đóng gói. **Chưa thể xác nhận Typst/Manim render thực trong môi trường tạo mã**; kết quả smoke-render tại GitHub và duyệt trực tiếp MP4 vẫn là điều kiện bắt buộc trước khi dùng giảng dạy.
