# STAT15 – Báo cáo nguồn và kiểm thử

- Chủ đề: phát hiện biểu đồ thống kê gây hiểu nhầm, tám chương, bốn phân cảnh/chương.
- Công thức: 8 nguồn Typst, phải biên dịch SVG thật khi render.
- Cơ chế hiển thị: từng phân cảnh có cùng hệ hai cột; tuyệt đối không đưa trạng thái điều phối ra màn hình; footer `Thầy Nguyễn Văn Sang`.
- Nguồn số liệu thống nhất: `stat15/lesson.py`; scene, kiểm thử và lời giảng sử dụng lại những số liệu này.
- TTS nam mặc định: `vi-VN-NamMinhNeural`.
- Kiểm thử mock: `python scripts/check_stat15_states.py` cho 32 hình và 32 khung lời giải (không thay thế được render thật).
- Kiểm thử toán và toàn bộ series: `python -m unittest discover -s tests -q`.
- Kiểm thử MP4: trong GitHub Actions, Manim smoke-render trước rồi QA ffprobe, âm thanh và tám ảnh chụp chương.
- Môi trường tạo mã không cài Manim/Typst; chưa có MP4 thực tế. Không được ghi là đã nghiệm thu hình hoặc tiếng.
