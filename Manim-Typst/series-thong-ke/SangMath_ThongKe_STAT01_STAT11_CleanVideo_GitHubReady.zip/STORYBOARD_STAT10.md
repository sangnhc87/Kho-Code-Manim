# STORYBOARD THONG-KE-10

Bố cục 16:9: dữ liệu và hình động bên trái, lập luận và SVG Typst bên phải.

Giá trị tứ phân vị ghép nhóm là nội suy xấp xỉ, không thay thế tứ phân vị dữ liệu gốc.

## Chương 01: KHÁM PHÁ TỨ PHÂN VỊ TỪ BẢNG GHÉP NHÓM

### Nhịp 1: Từ bốn mươi điểm sang bốn nhóm
- Luận điểm: Mẫu gốc có Q1=6, Q2=7, Q3=8.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 2: Tần số sau khi ghép nhóm
- Luận điểm: Bốn lớp có tần số 6, 18, 14, 2.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 3: Tứ phân vị chia dữ liệu thế nào?
- Luận điểm: Các mức tương ứng 25%, 50% và 75%.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 4: Một câu hỏi kiểm chứng
- Luận điểm: Tứ phân vị ghép nhóm không nhất thiết bằng tứ phân vị gốc.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

## Chương 02: BA MỨC TÍCH LŨY 25%, 50%, 75%

### Nhịp 1: Đọc dãy tích lũy
- Luận điểm: 6 → 24 → 38 → 40.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 2: Đặt ba mốc vị trí
- Luận điểm: n/4=10, n/2=20, 3n/4=30.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 3: Tìm lớp Q1 và Q2
- Luận điểm: Cả hai đều thuộc lớp [6;8).
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 4: Tìm lớp Q3
- Luận điểm: Mốc 30 thuộc lớp [8;10).
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

## Chương 03: NỘI SUY Q1: MỘT PHẦN TƯ TRONG BẢNG

### Nhịp 1: Định vị lớp thứ hai
- Luận điểm: Cận trái 6; độ rộng 2; tần số 18.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 2: Từ mốc 6 đến mốc 10
- Luận điểm: Cần đi 4 trong 18 quan sát của lớp.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 3: Công thức và kết quả Q1
- Luận điểm: Q1 ≈ 6 + (10−6)/18 × 2 = 6,44.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 4: Vì sao không lấy Q1 bằng 6?
- Luận điểm: Giá trị 6 thuộc dữ liệu gốc, không phải giá trị nội suy.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

## Chương 04: NỘI SUY Q2: CÙNG LỚP, KHÁC VỊ TRÍ

### Nhịp 1: Q2 cũng thuộc lớp [6;8)
- Luận điểm: Độ rộng 2, tần số 18, tích lũy trước 6.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 2: Q2 đi xa hơn Q1
- Luận điểm: Cần đi 14 trong 18 quan sát.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 3: Kết quả nội suy Q2
- Luận điểm: Q2 ≈ 6 + (20−6)/18 × 2 = 7,56.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 4: So sánh Q1 với Q2
- Luận điểm: 6,44 < 7,56; cùng lớp nhưng khác tỷ phần.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

## Chương 05: NỘI SUY Q3 VÀ KHOẢNG TỨ PHÂN VỊ

### Nhịp 1: Q3 chuyển sang lớp thứ ba
- Luận điểm: Cận trái 8, trước lớp 24, tần số 14.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 2: Mốc 30 nằm ở đâu trong lớp?
- Luận điểm: Cần đi 6 trong 14 quan sát.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 3: Hoàn tất ba tứ phân vị
- Luận điểm: Q3 ≈ 8,86; bộ ba ≈ 6,44; 7,56; 8,86.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 4: Khoảng tứ phân vị ước lượng
- Luận điểm: IQR ≈ 8,86 − 6,44 = 2,41.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

## Chương 06: OGIVE: ĐỌC BA PHÂN VỊ TRÊN ĐỒ THỊ

### Nhịp 1: Từ bảng sang đường tích lũy
- Luận điểm: Các đỉnh đường gấp khúc là (4,0),(6,6),(8,24),(10,38),(12,40).
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 2: Đường ngang 25 phần trăm
- Luận điểm: Mức 10 cắt đường tại Q1 ≈ 6,44.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 3: Đường ngang 50 và 75 phần trăm
- Luận điểm: Mức 20 cho Q2; mức 30 cho Q3.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 4: Tự đọc biểu đồ và kiểm tra
- Luận điểm: Q1 ≤ Q2 ≤ Q3; lớp và tích lũy phải khớp.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

## Chương 07: RANH GIỚI LỚP VÀ THAY ĐỔI CÁCH GHÉP

### Nhịp 1: Khi phần tư trùng đúng biên
- Luận điểm: Với tần số 10,10,10,10: Q1=6, Q2=8, Q3=10.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 2: Hai cách chọn lớp ở ranh giới
- Luận điểm: Cùng một ranh giới cho cùng giá trị.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 3: Đổi ranh giới, đổi ước lượng
- Luận điểm: Bảng khác cho Q1=6,5; Q2≈7,67; Q3≈8,78.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 4: Kiểm tra lại tính nhất quán
- Luận điểm: Các tứ phân vị luôn không giảm.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

## Chương 08: BÀI TOÁN NGƯỢC CÓ TẦN SỐ CHƯA BIẾT

### Nhịp 1: Bài ngược: tìm tần số x
- Luận điểm: Tần số là 6, x, 32−x, 2; n=40.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 2: Tạo phương trình từ Q1
- Luận điểm: 6 + (10−6)×2/x = 6,5.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 3: Tìm Q2 và Q3 theo bảng mới
- Luận điểm: Q2 = 7,75; Q3 = 9.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

### Nhịp 4: Kết luận và tự kiểm tra
- Luận điểm: Q1=6,5; Q2=7,75; Q3=9; IQR=2,5.
- Hoạt hình thay đổi theo trạng thái 1–4; công thức Typst xuất ở hai trạng thái cuối.
- Thời lượng thiết kế: 34 giây.

