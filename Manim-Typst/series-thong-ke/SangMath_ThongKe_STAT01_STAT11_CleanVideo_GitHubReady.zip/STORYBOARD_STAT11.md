# Storyboard STAT11 — 8 chương / 32 nhịp

Khung hình 16:9. Bên trái là dữ liệu và chuyển động, bên phải là suy luận và công thức.
Footer toàn video: **Thầy Nguyễn Văn Sang**. Không có tên công nghệ dựng video.

## Chương 01 — KHOẢNG BIẾN THIÊN: CỰC TRỊ GỐC VÀ RANH GIỚI LỚP
So sánh R gốc = 6 và R bảng ghép = 8; phân biệt ranh giới lớp.
Bốn nhịp: Hai cực trị của dữ liệu thô, Khoảng biến thiên của dữ liệu gốc, Nhưng bảng ghép nhóm chỉ cho khoảng, Khoảng biến thiên từ bảng.

## Chương 02 — KHOẢNG TỨ PHÂN VỊ: NỬA GIỮA CỦA DỮ LIỆU
Tìm Q1 ≈ 6,44; Q3 ≈ 8,86; IQR ≈ 2,41.
Bốn nhịp: Tại sao chỉ nhìn hai đầu là chưa đủ?, Nhắc lại ba tứ phân vị nội suy, Ý nghĩa khoảng tứ phân vị, Tính IQR cho bảng 40 điểm.

## Chương 03 — MÔ PHỎNG HAI THƯỚC ĐO ĐỘ PHÂN TÁN
Trục số thể hiện hai đoạn độ dài khác nhau và ví dụ ngoại lệ.
Bốn nhịp: Đặt hai thước đo lên cùng trục, Quan sát khoảng giữa, Đưa ngoại lệ vào dữ liệu gốc, Không suy ngoại lệ từ bảng tùy tiện.

## Chương 04 — SO SÁNH HAI MẪU CÓ CÙNG KHOẢNG BIẾN THIÊN
Hai histogram A và B cùng R = 8; IQR lần lượt 2,41 và 4.
Bốn nhịp: Hai mẫu có cùng lớp đầu và cuối, Bảng A tập trung nhiều ở giữa, Bảng B trải đều bốn lớp, Chọn thước đo để so sánh.

## Chương 05 — BIẾN ĐỔI DỮ LIỆU VÀ CÁC TÍNH CHẤT
Tịnh tiến +3, co giãn ×2; rút ra quy tắc trị tuyệt đối.
Bốn nhịp: Cộng cùng một hằng số, Nhân dữ liệu với hệ số dương, Nhân dữ liệu với hệ số âm, Không nhầm khi đổi đơn vị.

## Chương 06 — DỮ LIỆU GHÉP NHÓM CÓ THỂ LÀM MẤT GÌ?
Lớp trống và giới hạn thông tin của bảng ghép nhóm.
Bốn nhịp: Một bảng có thể che giấu cực trị, Đọc đúng lớp không có quan sát, Cùng bảng, nhiều dữ liệu gốc, Không gọi phép nội suy là chính xác.

## Chương 07 — NHỮNG SAI LẦM PHỔ BIẾN VÀ CÂU HỎI ĐẢO
Sửa lỗi: nhầm trung điểm lớp, nhầm Q1/Q3, giữ bảng cũ sau đổi dữ liệu.
Bốn nhịp: Sai lầm 1: lấy trung điểm lớp, Sai lầm 2: chọn hai lớp bất kỳ, Sai lầm 3: đưa điểm ngoài lớp, Câu hỏi đảo: biết R thì biết IQR?.

## Chương 08 — BÀI TOÁN VẬN DỤNG VÀ TỔNG KẾT
Thực hành tính R và IQR, kết luận và kết nối Video 12.
Bốn nhịp: Bài tập: tìm R ghép nhóm, Bài tập: tính IQR nội suy, Bài tập: so sánh hai mẫu, Tổng kết và nối sang phương sai.
