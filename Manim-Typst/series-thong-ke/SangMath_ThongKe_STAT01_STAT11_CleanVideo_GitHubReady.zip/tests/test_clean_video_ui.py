"""Protect classroom videos against accidentally revealing internal production counters."""
import ast
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class TestCleanVideoUI(unittest.TestCase):
    def test_no_internal_beat_status_visible(self):
        scene_files=sorted(ROOT.glob('stat[0-9][0-9]/scene.py'))
        self.assertGreaterEqual(len(scene_files),11)
        for p in scene_files:
            with self.subTest(episode=p.parent.name):
                src=p.read_text(encoding='utf-8')
                ast.parse(src)
                self.assertNotIn('NHỊP',src.upper(),
                    'Internal beat counter must never appear in classroom video')
                self.assertIn('Thầy Nguyễn Văn Sang',src)
    def test_stat11_correct_episode_title(self):
        src=(ROOT/'stat11'/'scene.py').read_text(encoding='utf-8')
        self.assertIn('THỐNG KÊ 11 / KHOẢNG BIẾN THIÊN',src)
        self.assertNotIn('THỐNG KÊ 12',src)

if __name__=='__main__': unittest.main()
