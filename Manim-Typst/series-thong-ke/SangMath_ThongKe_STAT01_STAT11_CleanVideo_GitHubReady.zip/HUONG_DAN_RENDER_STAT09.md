# Hướng dẫn render STAT09 – Trung vị của mẫu số liệu ghép nhóm

## Mục tiêu

- Video lớp 11 về trung vị của mẫu số liệu ghép nhóm, 8 chương/32 nhịp, nền **16 phút 32 giây**.
- Công thức Typst, phụ đề tiếng Việt, giọng đọc AI tùy chọn.
- Các dữ liệu, biểu đồ và nghiệm đều sinh từ mã `stat09/lesson.py`.

## Dùng trên GitHub

1. Giải nén bản ZIP đầy đủ, hoặc chép các tệp trong `SangMath_ThongKe_STAT09_Patch_GitHubReady.zip` vào **gốc** repository `sangmath-thong-ke` (giữ cấu trúc `.github`, `stat09`, `scripts`, `tests`, `typst`).
2. Commit, push lên GitHub.
3. Vào **Actions → Render STAT09 - Trung vi mau ghep nhom** → Run workflow.
4. Chọn `quality=preview`, `voice=off`. Đây là vòng kiểm tra đầu tiên không cần TTS.
5. Tải Artifacts; xem MP4, 8 ảnh QA và `report.json`.
6. Chạy `voice=on` để duyệt giọng đọc. Chỉ chạy `quality=fullhd` khi bản thử đã đạt.

## Quy trình kiểm lỗi được tự động hóa

1. `python -m unittest discover -s tests -v`: kiểm tra 9 tập, bao gồm lớp trung vị, nội suy, trường hợp biên và sai số ghép nhóm.
2. `python scripts/check_stat09_states.py`: gọi trực tiếp 32 hàm hình/ghi chú trong một môi trường Manim mô phỏng. Đây là **kiểm tra mã**, không phải render.
3. `python scripts/build_stat09_typst.py`: biên dịch **8 SVG thực tế**; thiếu công thức nào sẽ dừng.
4. `python scripts/prepare_stat09.py --voice off` hoặc `--voice on`: tạo 32 nhịp, lịch phát, phụ đề và tệp MP3 (nếu bật giọng đọc).
5. `manim -ql -r 426,240 --fps 8 stat09/scene.py STAT09_SMOKE`: render thực tế đủ 32 trạng thái, xác nhận Manim đọc SVG.
6. Render `STAT09` ở 854×480 (preview) hoặc 1920×1080 (fullhd).
7. `scripts/qa_stat09.py`: xác nhận thời lượng, kích thước MP4, kiểm âm thanh và trích ảnh từng chương.

## Lỗi thường gặp

- **Missing SVG / Typst compile failed:** kiểm tra bước biên dịch Typst và lỗi cú pháp trong `typst/stat09/*.typ`; không bỏ qua bước này.
- **TTS not available:** dùng `voice=off` trước, vì chế độ `on` cần internet đến dịch vụ TTS và phải có MP3 hợp lệ.
- **Smoke render failed:** xem dòng traceback ở `STAT09_SMOKE`, xác định hàm chương gây lỗi. Không chạy Full HD khi chưa sửa.
- **Time mismatch:** kiểm `stat09/runtime_plan.json` và ffprobe. Không kéo dài bằng cách chỉ sửa con số trong manifest.
- **Typst formula looks too small:** kiểm ảnh QA chương tương ứng, điều chỉnh kích cỡ SVG trước khi xuất Full HD.

## Công thức và điều kiện của bài

Với dữ liệu giả lập 40 điểm, các lớp [4;6), [6;8), [8;10), [10;12) có tần số 6, 18, 14, 2. Mốc tích lũy `n/2=20` nằm trong lớp [6;8).

`Me ≈ 6 + (20 - 6)/18 × 2 ≈ 7,56.` Trung vị gốc của 40 điểm **bằng 7**.

Giá trị ghép nhóm phụ thuộc cách chia lớp và giả thiết nội suy tuyến tính. Không dùng dấu bằng chính xác giữa số đo gốc và số nội suy.

## Trạng thái nghiệm thu

Đã kiểm tra mã, tính toán và mô phỏng trạng thái trong môi trường tạo mã. **Chưa chạy Manim/Typst thật tại đây**; việc render thực tế và duyệt sư phạm phải hoàn tất trên GitHub Actions.
