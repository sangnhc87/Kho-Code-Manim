# STORYBOARD STAT09

8 chương / 32 nhịp. Bố cục 16:9: hình/bảng bên trái, lập luận bên phải.
Các phương án nội suy được ghi là xấp xỉ. Không đưa đáp số trước lời giải.

## Chương 01: TRUNG VỊ GỐC VÀ CÂU HỎI KHI GHÉP NHÓM

### Nhịp 1 – Từ 40 điểm số đã quen
- Luận điểm: Trung vị chính xác của dữ liệu gốc bằng 7.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 2 – Bốn lớp và bốn tần số
- Luận điểm: Các tần số là 6, 18, 14, 2.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 3 – Vì sao không lấy trung điểm?
- Luận điểm: Trung điểm 7 không tự động là trung vị ghép nhóm.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 4 – Đặt câu hỏi nghiên cứu
- Luận điểm: Trung vị gốc và trung vị nội suy có nhất thiết bằng nhau?
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

## Chương 02: TẦN SỐ TÍCH LŨY VÀ VỊ TRÍ TRUNG VỊ

### Nhịp 1 – Bắt đầu tích lũy từ lớp đầu
- Luận điểm: Tần số tích lũy lần lượt 6, 24, 38, 40.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 2 – Vị trí giữa của 40 quan sát
- Luận điểm: n chia 2 bằng 20.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 3 – Sáu chưa đủ, hai mươi bốn vượt qua
- Luận điểm: 6 nhỏ hơn 20; 20 nhỏ hơn 24.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 4 – Đọc bảng như đường đi qua mốc
- Luận điểm: Lớp chứa trung vị là lớp thứ hai.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

## Chương 03: XÁC ĐỊNH ĐÚNG LỚP CHỨA TRUNG VỊ

### Nhịp 1 – Đánh dấu lớp [6;8)
- Luận điểm: Cận dưới L bằng 6; độ rộng h bằng 2.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 2 – Mốc trước lớp trung vị
- Luận điểm: Có 6 quan sát trước lớp trung vị.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 3 – Tần số của lớp trung vị
- Luận điểm: Lớp [6;8) chứa 18 quan sát.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 4 – Bốn đại lượng, một phép nội suy
- Luận điểm: L=6; N trước=6; f=18; h=2.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

## Chương 04: NỘI SUY TRONG LỚP TRUNG VỊ

### Nhịp 1 – Đi qua 14 trong 18 quan sát
- Luận điểm: Tỷ lệ nội suy là 14/18.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 2 – Biến tỷ lệ thành độ dài
- Luận điểm: Đoạn cộng thêm bằng 14/18 nhân 2.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 3 – Hoàn tất tính trung vị
- Luận điểm: M_e xấp xỉ 7,56.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 4 – Viết công thức tổng quát
- Luận điểm: M_e ≈ L + (n/2 − N trước)h/f.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

## Chương 05: ĐƯỜNG TẦN SỐ TÍCH LŨY VÀ MÔ HÌNH DIỆN TÍCH

### Nhịp 1 – Dựng đường tích lũy
- Luận điểm: Các điểm tích lũy: (4,0),(6,6),(8,24),(10,38),(12,40).
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 2 – Đường ngang tại n/2
- Luận điểm: Mức 20 cắt đoạn nối (6,6) với (8,24).
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 3 – Hạ đường vuông góc xuống trục
- Luận điểm: Hoành độ giao điểm là khoảng 7,56.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 4 – Hiểu đúng giả thiết hình học
- Luận điểm: Đoạn thẳng là một mô hình xấp xỉ.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

## Chương 06: ĐỔI RANH GIỚI LỚP: ĐỘ NHẠY CỦA ƯỚC LƯỢNG

### Nhịp 1 – Thay ranh giới, giữ nguyên dữ liệu
- Luận điểm: Bảng mới: 6, 8, 18, 8; tổng vẫn 40.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 2 – Lớp trung vị mới
- Luận điểm: Các tích lũy mới: 6, 14, 32, 40.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 3 – Nội suy lại với bảng mới
- Luận điểm: M_e mới ≈ 7,67.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 4 – Bài học về sai số do ghép nhóm
- Luận điểm: Ước lượng phụ thuộc cách chia lớp.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

## Chương 07: TRƯỜNG HỢP BIÊN VÀ CÁC LỖI DỄ MẮC

### Nhịp 1 – Mức n/2 rơi đúng ranh giới
- Luận điểm: Ví dụ tích lũy đạt đúng 10 ở cuối lớp [2;4).
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 2 – Không nhầm tần số với tích lũy
- Luận điểm: 20 thuộc đoạn tích lũy 6→24, không phải f=20.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 3 – Lớp rộng không đều vẫn dùng nội suy
- Luận điểm: Độ rộng h phải lấy riêng của lớp trung vị.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 4 – Ba phép kiểm trước kết luận
- Luận điểm: Đúng lớp, đúng tích lũy trước lớp, kết quả nằm trong lớp.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

## Chương 08: BÀI TẬP TỔNG HỢP VÀ TƯ DUY THỐNG KÊ

### Nhịp 1 – Bài tập: 20 thời lượng học tập
- Luận điểm: Bảng tần số là 5, 7, 6, 2.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 2 – Tìm lớp trung vị của bài luyện
- Luận điểm: Tích lũy: 5,12,18,20; lớp [4;6).
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 3 – Nội suy và kiểm chứng
- Luận điểm: M_e ≈ 5,43; trung vị dữ liệu gốc = 5.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

### Nhịp 4 – Tự kiểm tra và chuyển sang bài mới
- Luận điểm: Đúng thứ tự: tích lũy → lớp → bốn đại lượng → nội suy.
- Hình bên trái thay đổi theo trạng thái; nhịp 3–4 xuất công thức Typst.
- Thời lượng nền: 31 giây.

