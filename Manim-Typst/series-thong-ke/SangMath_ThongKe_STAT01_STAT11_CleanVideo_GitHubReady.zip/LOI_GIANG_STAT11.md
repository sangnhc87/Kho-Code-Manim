# STAT11 - Khoảng biến thiên và khoảng tứ phân vị của mẫu ghép nhóm

**Giáo viên:** Thầy Nguyễn Văn Sang  
**Thuyết minh:** giọng nam Việt Nam (Edge TTS `vi-VN-NamMinhNeural`)  
**Lịch trình:** 32 nhịp × 32 giây = 17 phút 04 giây trước TTS.

**Lưu ý:** SVG do Typst tạo; công nghệ không xuất hiện ở footer video.

## Chương 01: KHOẢNG BIẾN THIÊN: CỰC TRỊ GỐC VÀ RANH GIỚI LỚP

### Nhịp 1: Hai cực trị của dữ liệu thô
**Kết luận:** Điểm nhỏ nhất 4, lớn nhất 10.

**Lời giảng:** Hãy quan sát bốn mươi điểm kiểm tra đã dùng xuyên suốt các bài trước. Điểm nhỏ nhất của lớp là bốn, điểm lớn nhất là mười. Hiệu của hai điểm cho biết toàn bộ dãy trải rộng đến đâu. Nhưng một giá trị cực đoan cũng có thể làm thay đổi thước đo ấy rất nhanh, vì thế ta cần học thêm khoảng tứ phân vị.

### Nhịp 2: Khoảng biến thiên của dữ liệu gốc
**Kết luận:** R gốc = 10 − 4 = 6.

**Lời giảng:** Khoảng biến thiên của dữ liệu chưa ghép nhóm là số lớn nhất trừ số nhỏ nhất. Trong ví dụ này, mười trừ bốn bằng sáu. Giá trị sáu được xác định trực tiếp vì ta có cả danh sách. Hãy ghi nhớ điều kiện này: muốn tính khoảng biến thiên chính xác, phải biết chính xác hai giá trị cực trị.

### Nhịp 3: Nhưng bảng ghép nhóm chỉ cho khoảng
**Kết luận:** Lớp đầu [4;6), lớp cuối [10;12).

**Lời giảng:** Khi nhìn bảng bốn lớp, em không thấy điểm nhỏ nhất hay lớn nhất nằm chính xác ở đâu bên trong lớp đầu và lớp cuối. Bảng chỉ cho ranh giới lớp. Do vậy ta dùng hiệu ranh giới trên của lớp cuối có quan sát và ranh giới dưới của lớp đầu có quan sát. Đó là cách tính từ mẫu ghép nhóm.

### Nhịp 4: Khoảng biến thiên từ bảng
**Kết luận:** R ghép nhóm = 12 − 4 = 8.

**Lời giảng:** Lớp đầu có quan sát bắt đầu từ bốn và lớp cuối có quan sát kết thúc ở ranh giới mười hai. Bởi vậy khoảng biến thiên của bảng ghép nhóm là tám theo quy ước sử dụng ranh giới lớp. Nó không bằng khoảng biến thiên sáu của dữ liệu gốc, bởi trong lớp cuối thực tế chỉ có điểm mười, không có điểm mười hai.

## Chương 02: KHOẢNG TỨ PHÂN VỊ: NỬA GIỮA CỦA DỮ LIỆU

### Nhịp 1: Tại sao chỉ nhìn hai đầu là chưa đủ?
**Kết luận:** Khoảng biến thiên nhạy với điểm ngoại lệ.

**Lời giảng:** Khoảng biến thiên rất dễ hình dung, nhưng chỉ dựa vào hai điểm ở hai đầu. Nếu một học sinh có điểm số rất khác phần còn lại, hiệu hai cực trị có thể phình to trong khi phần lớn lớp học không thay đổi. Để hiểu mức tập trung của nửa giữa, ta dùng khoảng tứ phân vị.

### Nhịp 2: Nhắc lại ba tứ phân vị nội suy
**Kết luận:** Q1≈6,44; Q2≈7,56; Q3≈8,86.

**Lời giảng:** Bảng của chúng ta có tần số sáu, mười tám, mười bốn và hai. Ở tập mười, ba mốc tích lũy mười, hai mươi, ba mươi cho ba tứ phân vị nội suy. Q một khoảng sáu phẩy bốn bốn, Q hai khoảng bảy phẩy năm sáu và Q ba khoảng tám phẩy tám sáu. Đây là các giá trị ước lượng, không phải tứ phân vị gốc.

### Nhịp 3: Ý nghĩa khoảng tứ phân vị
**Kết luận:** IQR = Q3 − Q1.

**Lời giảng:** Q một chia khoảng một phần tư thấp nhất với phần còn lại; Q ba đánh dấu mốc ba phần tư. Khoảng từ Q một đến Q ba biểu diễn phần giữa của phân bố theo phương pháp nội suy đã chọn. Độ dài khoảng ấy gọi là khoảng tứ phân vị. Khác khoảng biến thiên, nó không chỉ được quyết định bởi hai cực trị.

### Nhịp 4: Tính IQR cho bảng 40 điểm
**Kết luận:** IQR ghép nhóm ≈ 2,41.

**Lời giảng:** Lấy tứ phân vị thứ ba trừ tứ phân vị thứ nhất, ta được hai phẩy bốn mươi mốt khi làm tròn đến hai chữ số. Để tránh sai số tích lũy, trong code và phép tính nên giữ phân số hoặc số chưa làm tròn rồi mới kết luận. Từ dữ liệu gốc, IQR chỉ bằng hai, nên ta vẫn phải phân biệt giá trị chính xác với ước lượng.

## Chương 03: MÔ PHỎNG HAI THƯỚC ĐO ĐỘ PHÂN TÁN

### Nhịp 1: Đặt hai thước đo lên cùng trục
**Kết luận:** R = 8; IQR ≈ 2,41.

**Lời giảng:** Trên trục từ bốn đến mười hai, đoạn lớn nối hai ranh giới xa nhất có độ dài tám. Một đoạn ngắn hơn nối Q một với Q ba có độ dài xấp xỉ hai phẩy bốn mươi mốt. Chúng cùng đo độ phân tán nhưng trả lời các câu hỏi khác nhau: toàn bộ phạm vi và độ rộng vùng giữa.

### Nhịp 2: Quan sát khoảng giữa
**Kết luận:** Tứ phân vị không phải phần trăm số điểm.

**Lời giảng:** Trong hình, vạch Q một và Q ba được đặt ở giá trị nội suy trên trục điểm. Ta không đọc hai phẩy bốn mươi mốt thành hai phẩy bốn mươi mốt phần trăm. Đây là độ chênh lệch điểm số, có cùng đơn vị với dữ liệu. Nếu điểm được đo theo mét hay phút, khoảng tứ phân vị cũng mang đơn vị tương ứng.

### Nhịp 3: Đưa ngoại lệ vào dữ liệu gốc
**Kết luận:** Đổi 10 thành 30: R gốc tăng từ 6 lên 26.

**Lời giảng:** Tưởng tượng thay một điểm mười trong bộ dữ liệu gốc bằng ba mươi, chỉ để khảo sát tác động toán học chứ không phải điểm kiểm tra hợp lệ trên thang mười. Khoảng biến thiên chính xác trở thành ba mươi trừ bốn, bằng hai mươi sáu. Các vị trí giữa gần như không thay đổi, nên độ phân tán trung tâm tương đối ổn định.

### Nhịp 4: Không suy ngoại lệ từ bảng tùy tiện
**Kết luận:** Cần bảng mới nếu giá trị vượt lớp cuối.

**Lời giảng:** Một sai lầm thường gặp là kéo điểm ba mươi ra ngoài biểu đồ nhưng vẫn giữ nguyên bốn lớp cũ. Cách đó không hợp lệ vì bảng mới đã bỏ sót một quan sát. Muốn tính lại khoảng biến thiên ghép nhóm, phải thiết lập lớp cuối chứa giá trị ba mươi hoặc xây dựng một bảng phân lớp mới. Không dùng biểu đồ cũ cho dữ liệu đã thay đổi.

## Chương 04: SO SÁNH HAI MẪU CÓ CÙNG KHOẢNG BIẾN THIÊN

### Nhịp 1: Hai mẫu có cùng lớp đầu và cuối
**Kết luận:** Cả hai có R ghép nhóm bằng 8.

**Lời giảng:** Xét bảng A quen thuộc với bốn tần số sáu, mười tám, mười bốn, hai. Bây giờ xét bảng B có mười quan sát ở mỗi lớp. Mỗi bảng đều có quan sát ở lớp đầu và lớp cuối; theo hiệu hai ranh giới, khoảng biến thiên ghép nhóm cùng bằng tám. Tuy nhiên mức tập trung của dữ liệu hoàn toàn khác nhau.

### Nhịp 2: Bảng A tập trung nhiều ở giữa
**Kết luận:** IQR A ≈ 2,41.

**Lời giảng:** Hai lớp ở giữa của mẫu A chiếm phần lớn số liệu, nên Q một và Q ba không cách nhau quá xa. Khoảng tứ phân vị nội suy khoảng hai phẩy bốn mươi mốt. Nhìn vào bốn cột, ta thấy chiều cao của hai cột giữa rõ ràng lớn hơn hai cột biên, phù hợp với mô tả ấy.

### Nhịp 3: Bảng B trải đều bốn lớp
**Kết luận:** IQR B = 4.

**Lời giảng:** Bảng B có tần số mỗi lớp đều bằng mười. Mốc một phần tư ở đúng ranh giới sáu, mốc ba phần tư ở đúng ranh giới mười, nên khoảng tứ phân vị bằng bốn. Lưu ý ranh giới trùng mức tích lũy được giải thích bằng hai lớp kề; hai cách nội suy cho cùng một ranh giới khi không có lớp trống.

### Nhịp 4: Chọn thước đo để so sánh
**Kết luận:** Cùng R chưa chắc cùng IQR.

**Lời giảng:** Hai mẫu có thể bằng nhau về độ rộng từ lớp đầu đến lớp cuối nhưng khác nhau rõ về độ tập trung ở giữa. Khi so sánh mức độ phân tán, ta không nên kết luận chỉ từ khoảng biến thiên. Hãy nhìn mục tiêu thực tế, bảng tần số và thêm khoảng tứ phân vị; nhiều khi dùng đồng thời hai thước đo sẽ hợp lý hơn.

## Chương 05: BIẾN ĐỔI DỮ LIỆU VÀ CÁC TÍNH CHẤT

### Nhịp 1: Cộng cùng một hằng số
**Kết luận:** R và IQR đều không đổi.

**Lời giảng:** Nếu cộng thêm ba vào mọi giá trị dữ liệu, các khoảng lớp phải dịch sang phải ba đơn vị. Khi đó hai ranh giới đầu và cuối đều tăng ba, nên hiệu của chúng giữ nguyên. Tương tự, Q một và Q ba đều tăng ba, nên khoảng tứ phân vị cũng không đổi. Đây là tính chất đơn giản mà rất hữu ích.

### Nhịp 2: Nhân dữ liệu với hệ số dương
**Kết luận:** R và IQR nhân với hệ số.

**Lời giảng:** Nếu nhân tất cả các giá trị và ranh giới lớp với hai, chiều dài mỗi đoạn trên trục tăng gấp đôi. Khoảng biến thiên từ tám thành mười sáu; khoảng tứ phân vị từ khoảng hai phẩy bốn mươi mốt thành gần bốn phẩy tám ba. Đây không phải mẹo nhớ mà là tính chất của hiệu hai giá trị.

### Nhịp 3: Nhân dữ liệu với hệ số âm
**Kết luận:** Độ rộng nhân với trị tuyệt đối.

**Lời giảng:** Nếu nhân với một hệ số âm, thứ tự các giá trị đảo ngược. Ta phải sắp lại lớp từ thấp đến cao; tứ phân vị đầu và cuối hoán đổi vai trò. Tuy nhiên độ dài khoảng vẫn không âm và được nhân với trị tuyệt đối của hệ số. Vì vậy R và IQR biến đổi theo độ lớn của phép co giãn.

### Nhịp 4: Không nhầm khi đổi đơn vị
**Kết luận:** Độ phân tán mang đơn vị dữ liệu.

**Lời giảng:** Điểm số, phút và centimet là những đơn vị khác nhau. Nếu đổi phút sang giây, mọi khoảng thời gian và cả khoảng biến thiên, IQR sẽ tăng sáu mươi lần về giá trị số. Không thể so sánh trực tiếp số đo độ phân tán của hai biến có đơn vị khác nhau mà không nói rõ đơn vị hoặc chuẩn hóa thích hợp.

## Chương 06: DỮ LIỆU GHÉP NHÓM CÓ THỂ LÀM MẤT GÌ?

### Nhịp 1: Một bảng có thể che giấu cực trị
**Kết luận:** Lớp [10;12) không chứa điểm 12.

**Lời giảng:** Trong ví dụ 40 điểm, lớp cuối là từ mười đến dưới mười hai nhưng cả hai quan sát đều có điểm mười. Chỉ nhìn bảng, ta không biết chi tiết ấy. Nếu tưởng rằng có học sinh đạt điểm mười hai, đó là suy diễn sai. Khoảng biến thiên ghép nhóm dùng ranh giới như một phép mô tả theo bảng, không phải sự xác nhận đã quan sát thấy các đầu mút.

### Nhịp 2: Đọc đúng lớp không có quan sát
**Kết luận:** Chọn lớp đầu và cuối có tần số dương.

**Lời giảng:** Giả sử một bảng có lớp đầu tiên mang tần số bằng không. Khi tính khoảng biến thiên từ bảng ghép nhóm, ta không lấy ranh giới của lớp trống làm cực trị mô tả. Hãy tìm lớp đầu có ít nhất một quan sát và lớp cuối có ít nhất một quan sát, rồi lấy ranh giới tương ứng. Chương trình cần kiểm tra điều này.

### Nhịp 3: Cùng bảng, nhiều dữ liệu gốc
**Kết luận:** Không phục hồi chính xác cực trị.

**Lời giảng:** Trong cùng một lớp từ sáu đến dưới tám, các điểm có thể nằm gần sáu hoặc gần tám. Rất nhiều bộ dữ liệu thô khác nhau có thể tạo đúng một bảng tần số ghép nhóm. Vì thế hai bộ có cùng bảng sẽ có cùng chỉ số nội suy theo công thức, nhưng vẫn có thể khác nhau về khoảng biến thiên và tứ phân vị thật.

### Nhịp 4: Không gọi phép nội suy là chính xác
**Kết luận:** Độ chính xác phụ thuộc cách chia lớp.

**Lời giảng:** Ghép nhóm là một sự đánh đổi: hình và bảng dễ đọc hơn nhưng mất thông tin chi tiết. Với lớp càng rộng, ta thường càng khó biết chính xác vị trí các giá trị bên trong. Khi báo cáo Q một, Q ba và khoảng tứ phân vị từ bảng, phải nhấn mạnh đây là các kết quả ước lượng theo phép nội suy đã chọn.

## Chương 07: NHỮNG SAI LẦM PHỔ BIẾN VÀ CÂU HỎI ĐẢO

### Nhịp 1: Sai lầm 1: lấy trung điểm lớp
**Kết luận:** R ghép nhóm không bằng hiệu trung điểm.

**Lời giảng:** Để ước lượng số trung bình, ta có thể dùng trung điểm lớp. Nhưng khi tính khoảng biến thiên ghép nhóm theo quy ước đang học, ta dùng ranh giới của lớp đầu và lớp cuối có quan sát, không dùng trung điểm của hai lớp ấy. Nếu lấy mười một trừ năm bằng sáu, ta đã dùng sai quy tắc cho bảng đang xét.

### Nhịp 2: Sai lầm 2: chọn hai lớp bất kỳ
**Kết luận:** IQR phải từ Q3 trừ Q1.

**Lời giảng:** Một số em lấy hai ranh giới sáu và mười rồi kết luận IQR bằng bốn, vì chúng trông như hai vạch phân chia. Không đúng. Q một và Q ba phải được xác định từ mức tích lũy một phần tư và ba phần tư; sau khi nội suy, ta mới lấy hiệu hai giá trị. Với bảng A, hiệu đó xấp xỉ hai phẩy bốn mươi mốt.

### Nhịp 3: Sai lầm 3: đưa điểm ngoài lớp
**Kết luận:** Nếu dữ liệu đổi, phải ghép nhóm lại.

**Lời giảng:** Khi có một giá trị lớn khác thường, ta không thể tự vẽ điểm ngoài trục rồi tuyên bố bảng ghép nhóm vẫn giữ nguyên tổng tần số và ranh giới cũ. Hãy lập lại bảng mới, kiểm tra tổng số quan sát và các khoảng có phủ hết dữ liệu không. Bảng phải nhất quán với các điểm đang được mô tả.

### Nhịp 4: Câu hỏi đảo: biết R thì biết IQR?
**Kết luận:** Không thể suy ra IQR chỉ từ R.

**Lời giảng:** Hãy nhìn lại hai bảng A và B. Cùng khoảng biến thiên bằng tám, nhưng một bảng có IQR gần hai phẩy bốn mươi mốt, bảng kia có IQR bằng bốn. Như vậy chỉ biết khoảng biến thiên thì chưa đủ để suy ra độ phân tán trung tâm. Muốn trả lời, cần biết thêm phân bố tần số hoặc thông tin về các tứ phân vị.

## Chương 08: BÀI TOÁN VẬN DỤNG VÀ TỔNG KẾT

### Nhịp 1: Bài tập: tìm R ghép nhóm
**Kết luận:** Bảng A có R bằng 8.

**Lời giảng:** Bài thứ nhất hãy xác định lớp có quan sát đầu tiên và cuối cùng của bảng A, rồi tìm khoảng biến thiên từ ranh giới. Ta không lấy điểm mười đã quan sát làm đầu cuối nếu đề chỉ cho bảng ghép nhóm; ranh giới trên của lớp cuối là mười hai, ranh giới dưới lớp đầu là bốn. Hiệu bằng tám.

### Nhịp 2: Bài tập: tính IQR nội suy
**Kết luận:** IQR A ≈ 2,41.

**Lời giảng:** Hãy dùng tần số tích lũy sáu, hai mươi bốn, ba mươi tám, bốn mươi. Mốc mười nằm ở lớp hai, mốc ba mươi ở lớp ba. Nội suy lần lượt Q một bằng sáu phẩy bốn bốn và Q ba bằng tám phẩy tám sáu. Giữ kết quả chính xác trong khi tính rồi mới làm tròn hiệu để được khoảng hai phẩy bốn mươi mốt.

### Nhịp 3: Bài tập: so sánh hai mẫu
**Kết luận:** R bằng nhau nhưng IQR A nhỏ hơn B.

**Lời giảng:** Bài thứ ba dùng bảng B với bốn tần số mười, mười, mười, mười. Khoảng biến thiên vẫn bằng tám, nhưng tứ phân vị đầu ở sáu và tứ phân vị cuối ở mười, cho IQR bằng bốn. Như vậy bảng B phân tán hơn A trong vùng giữa, theo thước đo IQR. Hãy kết luận đúng phạm vi của nhận xét.

### Nhịp 4: Tổng kết và nối sang phương sai
**Kết luận:** Hai thước đo chưa mô tả hết phân bố.

**Lời giảng:** Kết thúc tập này, em cần phân biệt khoảng biến thiên gốc và ghép nhóm, hiểu ý nghĩa của Q ba trừ Q một, và biết so sánh hai bảng không máy móc. Tập tiếp theo sẽ xét phương sai và độ lệch chuẩn của mẫu ghép nhóm. Khi đó chúng ta sử dụng thông tin từ tất cả các lớp, thay vì chỉ dựa vào cực trị hay các tứ phân vị.
