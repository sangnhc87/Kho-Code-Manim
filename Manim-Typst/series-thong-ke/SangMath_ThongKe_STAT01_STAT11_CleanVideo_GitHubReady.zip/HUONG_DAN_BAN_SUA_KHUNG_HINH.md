# Bản sửa sạch khung hình cho STAT01–STAT11

**Vấn đề:** dòng `CHƯƠNG 02/08 • NHỊP 2/4` là trạng thái sản xuất nội bộ đã bị đặt trong bảng lời giải của cả 11 video; ngoài ra header STAT11 bị ghi nhầm là THỐNG KÊ 12.

**Đã sửa:** bỏ hoàn toàn dòng tiến độ khỏi 11 `scene.py`, đẩy tiêu đề ý chính lên phía trên, sửa header STAT11 và thêm kiểm thử `tests/test_clean_video_ui.py`. Vẫn giữ đầy đủ cấu trúc 32 nhịp, lời đọc và mốc đồng bộ ở bên trong chương trình.

**Bản patch:** giải nén vào gốc repo `sangmath-thong-ke`, ghi đè 11 file `statXX/scene.py`, bổ sung `tests/test_clean_video_ui.py`, rồi commit/push.

**Bản toàn bộ:** thay thế bộ mã cũ sau khi sao lưu cấu hình riêng của repo.

**Quan trọng:** MP4 cũ đã xuất sẽ không tự sửa. Cần chạy lại GitHub Actions để tạo MP4 mới. Hãy chọn `voice = off, quality = preview` để duyệt khung hình trước, sau đó xuất bản thuyết minh/Full HD.

**Phạm vi kiểm thử:** có kiểm thử cú pháp và kiểm thử hồi quy nhãn hiển thị; không khẳng định đã nghiệm thu Manim/Typst thực tế nếu chưa render GitHub.
