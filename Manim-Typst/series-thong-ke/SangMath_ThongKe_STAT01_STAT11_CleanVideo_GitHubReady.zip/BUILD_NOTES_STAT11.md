# Build notes STAT11

- 32 trạng thái gồm 8 chương, 8 SVG Typst.
- So sánh khoảng biến thiên gốc R=6 và khoảng biến thiên theo ranh giới lớp R=8.
- Q1 = 58/9, Q3 = 62/7, IQR = 152/63 ≈ 2,41.
- Mẫu B có tần số (10,10,10,10), cùng R=8, IQR=4.
- Voice: vi-VN-NamMinhNeural (giọng nam); footer: Thầy Nguyễn Văn Sang.
- Previous STAT01–10 scene credits and TTS defaults updated consistently.
- Real Typst/Manim compilation must be run on GitHub Actions; mock ≠ render.
