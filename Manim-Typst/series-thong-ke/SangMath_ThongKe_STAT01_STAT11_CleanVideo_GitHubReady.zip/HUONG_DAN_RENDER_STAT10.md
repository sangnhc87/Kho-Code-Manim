# STAT10 — HƯỚNG DẪN RENDER GITHUB ACTIONS

## 1. Nội dung

STAT10: **Tứ phân vị của mẫu số liệu ghép nhóm** (32 nhịp, 8 chương, nền 18:08). Bộ dữ liệu giả lập của STAT01–09 tiếp tục được sử dụng. Các kết quả ghi dấu xấp xỉ vì được nội suy trong lớp:

| Phân vị | Mức tích lũy | Lớp | Công thức | Ước lượng |
|---|---:|---|---|---:|
| Q1 | 10 | [6;8) | 6 + (10-6)/18 × 2 | 6,44 |
| Q2 | 20 | [6;8) | 6 + (20-6)/18 × 2 | 7,56 |
| Q3 | 30 | [8;10) | 8 + (30-24)/14 × 2 | 8,86 |

Khoảng tứ phân vị ước lượng khoảng **2,41**. Bộ dữ liệu gốc có Q1=6, Q2=7, Q3=8, IQR=2. Các kết quả này KHÔNG mâu thuẫn.

## 2. Cập nhật repository

- Có sẵn STAT01–09: giải nén `SangMath_ThongKe_STAT10_Patch_GitHubReady.zip` vào thư mục gốc repo, rồi commit và push.
- Chưa có các tập: giải nén `SangMath_ThongKe_STAT01_STAT10_GitHubReady.zip` vào repo mới.
- Không chỉ upload thư mục `stat10`: workflow còn cần `scripts/`, `typst/`, `tests/` và `requirements.txt`.

## 3. Chạy

GitHub → Actions → **Render STAT10 - Tu phan vi mau ghep nhom** → Run workflow.

1. Chọn `quality=preview` và `voice=off` để kiểm tra hình trước.
2. Workflow kiểm thử Python, kiểm tra 32 trạng thái, biên dịch Typst ra tám SVG, dựng smoke-render với Manim, rồi mới render bài chính.
3. Tải `STAT10-preview-voice-off` trong Artifacts, xem MP4 và tám ảnh `chapter_01.jpg` đến `chapter_08.jpg`.
4. Nếu hình, chữ, ký hiệu và thời gian ổn, chạy tiếp `voice=on` (TTS tiếng Việt yêu cầu Internet).
5. Sau cùng chạy `quality=fullhd` → 1920×1080, 30 FPS.

## 4. Nếu build lỗi

- **Typst compile failed**: mở log bước `Compile all STAT10 Typst formula SVGs`, xem file nào trong `typst/stat10/` bị lỗi cú pháp. Quy trình cố ý dừng khi thiếu SVG, không âm thầm bỏ công thức.
- **Manim traceback**: xem bước `Smoke-render all 32 complete states`. Lỗi thuộc cảnh nào cần sửa tại `stat10/scene.py`; tuyệt đối không bỏ bước smoke để chạy trực tiếp Full HD.
- **Missing Vietnamese font**: kiểm tra log `fc-match 'Noto Sans'` và bước apt-get.
- **TTS failed**: thử `voice=off` để cách ly lỗi Internet/giọng đọc; không thay tiếng bằng bản im lặng và báo là đã có giọng đọc.
- **QA failed**: so sánh MP4 thực tế với `stat10/runtime_plan.json`, kiểm tra độ dài, độ phân giải, âm thanh và frame kiểm tra.

## 5. Kiểm tra cục bộ (nếu đã cài Manim và Typst)

```bash
python -m unittest discover -s tests -v
python scripts/check_stat10_states.py
python scripts/build_stat10_typst.py
python scripts/prepare_stat10.py --voice off
manim -ql -r 426,240 --fps 8 stat10/scene.py STAT10_SMOKE
manim -ql -r 854,480 --fps 24 stat10/scene.py STAT10
```

`check_stat10_states.py` chỉ là MOCK các đối tượng Manim, KHÔNG thay cho render thật.

## 6. Trạng thái bàn giao

Code và phép đếm được kiểm thử bằng Python; storyboard chỉ là minh họa thiết kế. Môi trường soạn tập này chưa có binary Manim/Typst nên **chưa có MP4 đã render và nghiệm thu**. Kết quả trên GitHub Actions và việc duyệt hình tiếng của giáo viên là bước cần thực hiện trước khi phát hành.
