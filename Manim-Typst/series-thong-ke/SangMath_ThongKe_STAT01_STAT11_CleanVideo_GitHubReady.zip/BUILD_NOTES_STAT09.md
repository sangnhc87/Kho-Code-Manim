# BUILD NOTES – STAT09

- Mã nguồn tổ chức độc lập: `stat09/lesson.py` (toán học + 32 nhịp) và `stat09/scene.py` (8 nhóm hoạt hình).
- `grouped_median()` kiểm tra các lớp liên tiếp, tổng tần số dương, tần số nguyên không âm. Nếu mốc n/2 trùng ranh giới thì dùng lớp không rỗng tiếp theo; phép nội suy trả đúng ranh giới.
- Bộ dữ liệu chính: tổng 40, tích lũy 6/24/38/40, trung vị ghép nhóm 68/9 ≈ 7,5556; trung vị dữ liệu gốc 7.
- Đổi khoảng: trung vị nội suy 23/3 ≈ 7,6667.
- Luyện tập: 20 quan sát, trung vị nội suy 38/7 ≈ 5,4286; trung vị gốc 5.
- Thời lượng nền: 992 giây = 16:32; có 32 nhịp, 8 chương, lời đọc và phụ đề khớp mỗi nhịp.
- Đã chuẩn bị workflow bắt buộc **biên dịch SVG Typst thực tế**, **smoke-render Manim 32 trạng thái** rồi mới render video đầy đủ trên GitHub.
- Giới hạn: môi trường hiện tại không có lệnh Manim/Typst; mock state check và Python unittest không thay thế được MP4 đã render thật.
