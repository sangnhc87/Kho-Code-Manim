# BUILD NOTES – STAT10

- Tách `stat10/lesson.py` (toán, nội dung, dữ liệu) và `stat10/scene.py` (8 mô hình trực quan, 32 trạng thái).
- Tất cả phép tính trực tiếp dựa trên bảng n=40, f=(6,18,14,2), tích lũy=(6,24,38,40) và mô hình nội suy tuyến tính.
- Nguồn gốc: Q1=6, Q2=7, Q3=8; ghép nhóm: Q1≈6,44, Q2≈7,56, Q3≈8,86; IQR≈2,41.
- Trường hợp mức mục tiêu trùng ranh giới lớp có tần số dương: nội suy từ hai phía cho cùng một ranh giới. Lớp trống có đoạn tích lũy phẳng: chú thích rõ tính không duy nhất về diễn giải tại đoạn phẳng.
- Đã có dữ liệu, lời giảng, Typst source, SRT, runtime_plan.json (voice-off), storyboard và kiểm thử trên toàn repo.
- GitHub Actions bắt buộc qua Python → Typst SVG → prepare TTS → Manim smoke 32 trạng thái → render MP4 → ffprobe QA + 8 ảnh.
- Kịch bản TTS căn thời gian từng nhịp theo thời lượng giọng đọc. Không coi kế hoạch thời lượng là thời lượng MP4 đã render.
- Tại môi trường soạn hiện chưa có binary `manim`/`typst`: KHÔNG khẳng định kiểm thử render thật đạt.
