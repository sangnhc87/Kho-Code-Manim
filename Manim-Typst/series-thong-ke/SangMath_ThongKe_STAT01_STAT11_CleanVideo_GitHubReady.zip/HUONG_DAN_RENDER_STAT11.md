# Hướng dẫn STAT11: Khoảng biến thiên và IQR ghép nhóm

1. Đưa nội dung ZIP/patch vào repository Thống kê, commit rồi push.
2. Mở **Actions → Render STAT11 - Khoang bien thien va IQR ghep nhom**.
3. Chạy `quality=preview`, `voice=off`. Pipeline: unittest → kiểm tra 32 trạng thái → Typst compile 8 SVG → lập lịch 32 nhịp → Manim smoke-render → MP4 → ffprobe/ảnh QA.
4. Duyệt hình và chữ. Sau đó chạy `voice=on` để sinh 32 đoạn thuyết minh giọng nam `vi-VN-NamMinhNeural`. Không dùng lại âm thanh nữ được tạo ở các bản cũ.
5. Nếu nghe tiếng và xem hình đạt yêu cầu, chạy `quality=fullhd` để xuất 1920×1080 / 30 FPS.

**Định dạng hiển thị trong video:** Footer `Thầy Nguyễn Văn Sang`. Không hiện nhãn `Manim–Typst`; phần mềm tạo video vẫn dùng nội bộ.

**Chú ý phát âm:** `vi-VN-NamMinhNeural` là giọng **nam giới** tiếng Việt. Nếu yêu cầu nghĩa là **giọng miền Nam**, dịch vụ TTS này không cam kết chính xác phương ngữ; cần chọn/kiểm thử dịch vụ âm thanh khác.

**Khi build lỗi:**
- `STAT11 Typst SVG missing`: kiểm tra step `build_stat11_typst.py` và file đầu vào `typst/stat11/*.typ`.
- `STAT11_SMOKE` lỗi: lấy log traceback; workflow cố tình smoke-render tất cả 32 trạng thái trước render dài.
- Không có âm thanh khi `voice=on`: Edge TTS thường do kết nối/giọng; workflow sẽ fail sớm.
- Cảnh có chữ khuất: duyệt 8 ảnh QA trong Artifacts.

**Trạng thái:** Chưa render MP4 thực tế trong môi trường soạn. Mã đã qua test Python và mô phỏng 32 trạng thái.
