# SANGMATH – Thống kê trực quan (18 tập dự kiến)

- **STAT01:** Dữ liệu biết nói – thống kê lớp 10.
- **STAT02:** Các loại biểu đồ, tần số và tần số tương đối.
- **STAT03:** Số trung bình, trung vị và mốt.
- **STAT04:** Tứ phân vị Q1, Q2, Q3.
- **STAT05:** Khoảng biến thiên, IQR và biểu đồ hộp.
- **STAT06:** Phương sai và độ lệch chuẩn – mã hoàn chỉnh, chờ nghiệm thu MP4 thực tế.
- **STAT07–18:** Chưa lập trình; gồm thống kê ghép nhóm, so sánh mẫu và các chủ đề mở rộng.

Mỗi tập có lời giảng đầy đủ, một storyboard, tệp Python dựng Manim, Typst, unit tests và workflow GitHub riêng. Các kết luận đều được tính từ dữ liệu xác định, không từ ảnh vẽ tay.

Với STAT06: 32 nhịp, 8 chương, 912 giây nền, quy ước phương sai mô tả chia cho n, dữ liệu 40 điểm giả lập nhất quán với các tập trước. Bắt buộc smoke-render đủ 32 trạng thái bằng Manim thật trên GitHub.
