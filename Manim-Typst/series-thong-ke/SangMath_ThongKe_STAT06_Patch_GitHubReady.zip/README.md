# SANGMATH – Thống kê trực quan Manim + Typst

## Trạng thái

- STAT01 đến STAT05: giữ nguyên mã đã phát hành; chưa mặc nhiên xem MP4 là đã nghiệm thu.
- STAT06: **Phương sai và độ lệch chuẩn**, 8 chương, 32 nhịp (15 phút 12 giây nền). Unit tests và dựng mô phỏng 32 trạng thái; render MP4 thật phải chạy trên GitHub Actions.

## Tài liệu STAT06

- `stat06/lesson.py`: dữ liệu, các bất biến toán học và 32 nhịp thuyết minh.
- `stat06/scene.py`: Manim Scene `STAT06` và Scene kiểm tra đủ 32 trạng thái `STAT06_SMOKE`.
- `typst/stat06/`: 8 công thức riêng; `scripts/build_stat06_typst.py` biên dịch thành `assets/stat06_formulas/*.svg`.
- `scripts/prepare_stat06.py`: tạo lịch phát/MP3 tùy chọn/phụ đề.
- `scripts/check_stat06_states.py`: phát hiện lỗi biến hoặc tên hàm ở tất cả nhịp mà không phải tải Manim.
- `scripts/qa_stat06.py`: kiểm tra MP4 đầu ra, âm thanh, thời lượng và xuất tám ảnh QA.
- `STORYBOARD_STAT06.md`, `LOI_GIANG_STAT06.md`, `HUONG_DAN_RENDER_STAT06.md`.
- `.github/workflows/render-stat06.yml`: workflow nhập chất lượng và giọng đọc.

Bộ dữ liệu chung: điểm 4 có tần số 2, điểm 5 có 4, điểm 6 có 8, điểm 7 có 10, điểm 8 có 8, điểm 9 có 6, điểm 10 có 2. Giá trị toán học: n=40, trung bình 7,1, phương sai 2,29, độ lệch chuẩn khoảng 1,513.

**Tuyệt đối không gọi kiểm thử Python là kết quả render.** Chỉ đánh dấu hoàn thiện sư phạm sau khi xem MP4 chính thức từ GitHub Actions.
