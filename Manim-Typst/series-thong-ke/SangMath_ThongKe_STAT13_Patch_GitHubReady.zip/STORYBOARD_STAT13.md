# STORYBOARD STAT13 – SO SÁNH HAI MẪU SỐ LIỆU

**Chuẩn video:** hai cột cố định, hình học–biểu đồ bên trái, đề bài–lập luận bên phải.
**Footer:** Thầy Nguyễn Văn Sang. Không dùng nhãn điều phối hay số bước nội bộ trên video.
**Phân cảnh:** 8 chương, mỗi chương 4 trạng thái. Công thức SVG xuất hiện từ trạng thái thứ ba của chương.
**Thống kê:** phương sai chia cho n; quy ước tứ phân vị theo trung vị của hai nửa mẫu.

## Chương 01. VÌ SAO PHẢI SO SÁNH NHIỀU TIÊU CHÍ?

**Minh họa:** Hai trục điểm và vạch trung bình cùng vị trí.

**Hai nhóm có cùng điểm trung bình**
- Luận điểm chính: Cùng trung bình 7 chưa chắc phân bố giống nhau.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Quan sát các điểm trên trục số**
- Luận điểm chính: Đám điểm A tụ lại; B trải rộng hơn.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Cùng một tâm, nhiều hình dạng**
- Luận điểm chính: Trung bình không mô tả toàn bộ mẫu.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Đặt câu hỏi so sánh đúng**
- Luận điểm chính: So sánh điều gì phụ thuộc mục tiêu.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

## Chương 02. SO SÁNH VỊ TRÍ TRUNG TÂM

**Minh họa:** Hai dãy điểm sắp tăng dần, lần lượt hiện ba số đo trung tâm.

**Tính trung bình có kiểm chứng**
- Luận điểm chính: A và B đều có tổng điểm 70, trung bình 7.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Trung vị cũng bằng nhau**
- Luận điểm chính: Hai giá trị giữa đều là 7 ở cả hai nhóm.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Kiểm tra mốt**
- Luận điểm chính: Giá trị 7 xuất hiện bốn lần ở mỗi nhóm.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Ba chỉ số trung tâm chưa đủ**
- Luận điểm chính: Cần thêm khoảng biến thiên, IQR và độ lệch chuẩn.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

## Chương 03. TỨ PHÂN VỊ VÀ BIỂU ĐỒ HỘP

**Minh họa:** Dựng hai biểu đồ hộp trên cùng trục; nhấn mạnh độ rộng hộp.

**Nhóm A: xác định ba tứ phân vị**
- Luận điểm chính: A: Q1=6, Q2=7, Q3=8.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Nhóm B: phần giữa rộng hơn**
- Luận điểm chính: B: Q1=4, Q2=7, Q3=10.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Dựng hai biểu đồ hộp**
- Luận điểm chính: Độ dài hộp A bằng 2; hộp B bằng 6.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**So sánh IQR và khoảng biến thiên**
- Luận điểm chính: A: R=4, IQR=2; B: R=6, IQR=6.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

## Chương 04. PHƯƠNG SAI VÀ ĐỘ LỆCH CHUẨN

**Minh họa:** Các chấm cách trung bình; nối các đoạn độ lệch và hiện phương sai.

**Vì sao cần độ lệch chuẩn**
- Luận điểm chính: Một chỉ số dùng mọi quan sát.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Phương sai của nhóm A**
- Luận điểm chính: A: tổng bình phương độ lệch = 12.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Phương sai của nhóm B**
- Luận điểm chính: B: tổng bình phương độ lệch = 54.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Kết luận bằng độ lệch chuẩn**
- Luận điểm chính: A: s≈1,095; B: s≈2,324.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

## Chương 05. SO SÁNH HAI BẢNG SỐ LIỆU GHÉP NHÓM

**Minh họa:** Hai histogram có cùng ranh giới lớp, trung điểm và tổng tần số.

**Từ dữ liệu thô sang bảng ghép nhóm**
- Luận điểm chính: Dùng cùng các lớp để so sánh công bằng.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Hai bảng cùng trung bình ghép nhóm**
- Luận điểm chính: Trung bình ước lượng đều là 7,6.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Khác biệt ở phương sai ghép nhóm**
- Luận điểm chính: A: s²≈2,44; B: s²≈4,44.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Nói rõ giới hạn của ước lượng**
- Luận điểm chính: Không suy ra chính xác các chỉ số gốc.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

## Chương 06. LỰA CHỌN CHỈ SỐ THEO MỤC TIÊU

**Minh họa:** Hai dãy ô màu đạt chuẩn, thay ngưỡng từ sáu đến chín.

**Mục tiêu: nhiều học sinh đạt từ 6**
- Luận điểm chính: A: 9/10; B: 7/10 đạt ít nhất 6.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Mục tiêu: số điểm từ 9 trở lên**
- Luận điểm chính: A: 1/10; B: 3/10 đạt ít nhất 9.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Không chỉ chọn theo một số đo**
- Luận điểm chính: Trung bình bằng nhau không quyết định lựa chọn.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Quy trình ra quyết định**
- Luận điểm chính: Mục tiêu → chỉ số → kết luận có điều kiện.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

## Chương 07. GIỚI HẠN CỦA SỐ LIỆU VÀ KẾT LUẬN

**Minh họa:** Bốn thẻ cảnh báo: đơn vị, ngoại lệ, tính đại diện, suy diễn.

**So sánh cần cùng thang đo**
- Luận điểm chính: Không đánh đồng điểm với thời gian.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Một giá trị cực đoan thay đổi điều gì**
- Luận điểm chính: Trung bình và phương sai có thể nhạy với ngoại lệ.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Quy mô mẫu và bối cảnh**
- Luận điểm chính: Mười điểm không thay thế nghiên cứu lớn.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Phát biểu kết luận có căn cứ**
- Luận điểm chính: Dùng “trong mẫu này”, không suy diễn nhân quả.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

## Chương 08. BÀI TẬP TỔNG HỢP VÀ PHƯƠNG PHÁP

**Minh họa:** Hai bài tập tám điểm; từng bước hiện trung bình, IQR, phương sai.

**Đọc đề và kiểm tra dữ liệu**
- Luận điểm chính: Hai mẫu tám điểm, cùng tổng 56.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Tính những số đo trung tâm**
- Luận điểm chính: Cả hai: trung bình 7, trung vị 7.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**So sánh tứ phân vị và phương sai**
- Luận điểm chính: IQR: 2 với 5; phương sai: 1,5 với 5,5.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.

**Viết kết luận và chọn mục tiêu**
- Luận điểm chính: Hai mẫu cùng tâm; A đồng đều hơn theo IQR và s.
- Cảnh hiển thị đúng phần kiến thức đang giảng, không hiện kết luận quá sớm.
- Chỉ thay đổi số liệu theo nguồn duy nhất trong stat13/lesson.py.
