# SangMath Thống kê – mã nguồn 13 bài học

**Tình trạng:** 13/18 tập có mã nguồn và workflow GitHub Actions. Để nghiệm thu bài giảng, phải render MP4 thật và xem lại hình ảnh, tiếng đọc trước khi phát hành.

## Tập mới: STAT13 – So sánh hai mẫu số liệu

**Kiến thức:** so sánh trung bình, trung vị, mốt, khoảng biến thiên, Q1–Q3, IQR, phương sai và độ lệch chuẩn; chọn chỉ số theo mục tiêu; lưu ý khác biệt giữa số liệu thô và ghép nhóm. Ví dụ giả lập A/B có cùng trung bình 7 nhưng phương sai 1,2 và 5,4.

**Cấu trúc:** 8 chương × 4 phân cảnh, có thuyết minh tiếng Việt, phụ đề SRT, công thức dựng qua Typst, 8 ảnh QA và bước smoke-render.

- Mã nguồn: `stat13/lesson.py`, `stat13/scene.py` (`STAT13` và `STAT13_SMOKE`).
- Typst: `typst/stat13/*.typ` → `assets/stat13_formulas/*.svg` (biên dịch trong Actions).
- Tạo lời đọc/phụ đề: `scripts/prepare_stat13.py` → `stat13/runtime_plan.json`, `STAT13_vi.srt`.
- GitHub: `.github/workflows/render-stat13.yml`.
- Kiểm thử: `python -m unittest discover -s tests -v`, `python scripts/check_stat13_states.py`.
- Lời giảng: `LOI_GIANG_STAT13.md`; storyboard: `STORYBOARD_STAT13.md`.
- Ảnh phác thảo: `preview/stat13/STAT13_storyboard_8_chapters.png`.
- Chi tiết: `HUONG_DAN_RENDER_STAT13.md`.

**Tiêu chuẩn bài giảng:** footer hiển thị **Thầy Nguyễn Văn Sang**, không có bộ đếm nhịp hoặc tên công nghệ trên màn hình. Giọng nam Việt `vi-VN-NamMinhNeural` nếu bật TTS. Bản preview dùng `voice=off`; bản có tiếng cần được nghe và duyệt.

## Các tập trước

Các tập STAT01–STAT12 và workflow riêng được giữ trong các thư mục `stat01/` đến `stat12/`; tài liệu của từng tập nằm ở `LOI_GIANG_STATXX.md`, `STORYBOARD_STATXX.md` và `HUONG_DAN_RENDER_STATXX.md` (riêng tập đầu có hướng dẫn chung).

**Quan trọng:** việc kiểm thử mô phỏng chỉ đảm bảo logic Python, không chứng minh bản MP4 thật được render đúng. GitHub Actions phải biên dịch công thức và chạy Manim trước khi duyệt.
