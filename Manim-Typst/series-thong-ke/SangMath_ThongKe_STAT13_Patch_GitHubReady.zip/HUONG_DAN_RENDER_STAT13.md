# STAT13 – Hướng dẫn GitHub Actions

**Tên bài:** So sánh hai mẫu số liệu. **Đối tượng:** học sinh THPT, Thống kê lớp 10–12.

## Render video

1. Giải nén **nội dung bên trong ZIP** vào gốc repository `sangmath-thong-ke`, giữ nguyên cấu trúc `.github/workflows/`, `stat13/`, `scripts/`, `tests/`, `typst/`.
2. Commit và push. Mở **Actions → Render STAT13 - So sanh hai mau so lieu → Run workflow**.
3. Trước tiên chọn `quality=preview`, `voice=off`. Workflow sẽ kiểm thử tất cả tập, kiểm tra 32 trạng thái, biên dịch tám nguồn Typst thành SVG, chuẩn bị timeline, smoke-render 32 trạng thái bằng Manim, sau đó render MP4 854×480 ở 24 fps.
4. Tải **Artifacts** gồm `STAT13.mp4`, SRT tiếng Việt, 8 ảnh chụp các chương và báo cáo QA. Kiểm tra biểu đồ, phương sai, phần thuyết minh của bài tập cuối, font dấu tiếng Việt và khả năng đọc chữ.
5. Khi hình đạt, chạy `voice=on` để dùng **giọng nam tiếng Việt** mặc định `vi-VN-NamMinhNeural`. GitHub runner cần mạng để gọi edge-tts. Kiểm tra giọng đọc thực tế, âm lượng và thời điểm chuyển hình.
6. Sau khi duyệt, chọn `quality=fullhd`, `voice=on` để xuất 1920×1080, 30 fps.

## Chuẩn hình thức

- Khung hình hai cột cố định: biểu đồ, mô hình ở trái; nội dung toán và công thức ở phải.
- Footer chỉ hiển thị **Thầy Nguyễn Văn Sang**. Không hiện bộ đếm, chỉ số nhịp, tên Scene, mã debug hay tên công nghệ lên video.
- Không hiện đáp số trước khi đã đặt vấn đề và giải thích.
- Ví dụ dữ liệu hoàn toàn mô phỏng; kết luận chỉ áp dụng trong các mẫu được cho.
- Phương sai chia cho **n**; với mẫu ghép nhóm, đại lượng tính theo trung điểm lớp mang tính **ước lượng**.

## Chạy thủ công trong môi trường đã có Manim và Typst

```bash
python -m unittest discover -s tests -v
python scripts/check_stat13_states.py
python scripts/build_stat13_typst.py
python scripts/prepare_stat13.py --voice off
manim -ql -r 426,240 --fps 8 stat13/scene.py STAT13_SMOKE
manim -ql -r 854,480 --fps 24 stat13/scene.py STAT13
```

## Xử lý lỗi

| Lỗi | Cách xử lý |
|---|---|
| Thiếu SVG | Kiểm tra bước `Compile 8 STAT13 Typst formulas`, tệp `typst/stat13/*.typ` và dòng lệnh Typst trong log. |
| Sai Scene hoặc hàm vẽ | Kiểm tra `scripts/check_stat13_states.py`, sau đó xem bước `Smoke render 32 actual states`. |
| Tràn chữ, nhầm màu, hình quá nhỏ | Xem 8 ảnh QA trong `artifacts/stat13_qa/` và render preview lại. |
| Voice on nhưng không có tiếng | Kiểm tra kết nối mạng, log edge-tts, tệp `.mp3`, và `scripts/qa_stat13.py`. |
| Thời lượng lệch | So sánh MP4 với `stat13/runtime_plan.json`; QA dừng nếu lệch quá 3 giây. |

**Giới hạn nghiệm thu:** Các phép thử Python và mô phỏng không thay thế render MP4 thật. Chỉ xuất bản sau khi GitHub Actions chạy thành công và thầy kiểm tra hình, tiếng.
