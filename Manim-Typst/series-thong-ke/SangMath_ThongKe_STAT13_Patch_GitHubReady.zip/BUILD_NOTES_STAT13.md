# STAT13 – Build notes

- Chủ đề: So sánh hai mẫu số liệu, chọn tiêu chí phù hợp với mục tiêu.
- Ví dụ chính: nhóm A và B đều có 10 quan sát, trung bình/trung vị/mốt cùng bằng 7; phương sai 1,2 và 5,4.
- Ví dụ ghép nhóm nối tiếp STAT12: trung bình ước lượng đều 7,6; phương sai 2,44 và 4,44.
- 8 chương × 4 trạng thái; mỗi trạng thái có lời giảng riêng; 8 nguồn Typst math.
- Lời đọc nam: vi-VN-NamMinhNeural. Footer: Thầy Nguyễn Văn Sang.
- Không hiển thị chỉ số nhịp, mã nội bộ hoặc tên công nghệ lên khung hình.
- Python unit test + mock state test kiểm tra mã nguồn; GitHub Actions đảm nhiệm render khói và MP4 thật.
