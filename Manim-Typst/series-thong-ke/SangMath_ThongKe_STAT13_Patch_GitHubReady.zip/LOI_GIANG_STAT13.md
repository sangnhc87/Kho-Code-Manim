# STAT13 – SO SÁNH HAI MẪU SỐ LIỆU

**Khối lớp:** 10–12, ôn tập và vận dụng thống kê mô tả.
**Đặc điểm:** bộ số liệu mô phỏng, lời đọc nam tiếng Việt. Hai mẫu 10 điểm giả lập dùng chung thang điểm.
**Nguyên tắc:** mô tả trong mẫu, không suy diễn quan hệ nhân quả hay suy rộng tổng thể.

## Chương 01. VÌ SAO PHẢI SO SÁNH NHIỀU TIÊU CHÍ?

### Hai nhóm có cùng điểm trung bình
Hãy quan sát hai nhóm học sinh, mỗi nhóm gồm mười điểm kiểm tra. Nhóm A phần lớn tập trung quanh bảy, còn nhóm B có nhiều điểm bốn và mười. Điều thú vị là trung bình của cả hai nhóm đều bằng bảy. Vậy ta có thể kết luận hai nhóm có kết quả giống nhau hay không?

### Quan sát các điểm trên trục số
Từng chấm trên trục số biểu diễn đúng một học sinh. Ở nhóm A, điểm thấp nhất là năm và cao nhất là chín. Ở nhóm B, biên độ mở rộng từ bốn đến mười. Khi xem hình, em có thể dự đoán nhóm B phân tán hơn, nhưng chúng ta cần đo điều đó bằng đại lượng phù hợp.

### Cùng một tâm, nhiều hình dạng
Giữ nguyên vạch trung bình ở vị trí bảy, hãy nhìn các chấm hai bên dịch chuyển. Mẫu A và mẫu B có cùng trung bình, song số điểm tập trung gần trung bình hoàn toàn khác nhau. Một thước đo trung tâm là chưa đủ để đánh giá sự đồng đều hay mức độ chênh lệch của các kết quả.

### Đặt câu hỏi so sánh đúng
Nếu muốn chọn lớp học ổn định, chúng ta quan tâm đến mức độ phân tán. Nếu muốn tìm học sinh xuất sắc, phải xem phần điểm cao. Nếu muốn đánh giá mức điểm điển hình, cần xét trung vị. Bài học sẽ lần lượt ghép các chỉ số lại, để đưa ra một kết luận có căn cứ thay vì chỉ nhìn một con số.

## Chương 02. SO SÁNH VỊ TRÍ TRUNG TÂM

### Tính trung bình có kiểm chứng
Bắt đầu với số trung bình cộng. Tổng mười điểm nhóm A là bảy mươi và nhóm B cũng bằng bảy mươi. Chia cho mười, cả hai cùng có trung bình bằng bảy. Việc kiểm tra tổng và cỡ mẫu là bước quan trọng, vì không thể so sánh trung bình một cách cẩn thận nếu nhập nhầm dữ liệu.

### Trung vị cũng bằng nhau
Với mười quan sát đã sắp xếp, trung vị là trung bình cộng của vị trí thứ năm và thứ sáu. Trong cả hai mẫu, hai vị trí đó cùng bằng bảy. Vì vậy trung vị đều là bảy, giống như trung bình. Tuy nhiên, hãy nhớ trung vị chỉ cho biết vị trí trung tâm, chưa đo độ rộng của dãy điểm.

### Kiểm tra mốt
Đếm số lần xuất hiện của từng điểm, ta thấy điểm bảy có tần số lớn nhất, đều là bốn ở hai nhóm. Như vậy cả mốt, trung vị lẫn trung bình đều trùng nhau. Đây là minh họa quan trọng: có thể ba số đo trung tâm bằng nhau nhưng mức phân tán giữa các nhóm vẫn rất khác biệt.

### Ba chỉ số trung tâm chưa đủ
Trung bình, trung vị và mốt là ba câu trả lời khác nhau về vị trí điển hình. Nhưng khi cả ba đều bằng bảy, ta vẫn chưa biết nhóm nào có nhiều điểm chênh lệch lớn. Bởi vậy bước tiếp theo là xác định tứ phân vị và khoảng biến thiên. Từ những kết quả ấy, hình dạng của hai phân bố sẽ lộ rõ hơn.

## Chương 03. TỨ PHÂN VỊ VÀ BIỂU ĐỒ HỘP

### Nhóm A: xác định ba tứ phân vị
Dữ liệu nhóm A đã sắp xếp tăng dần. Chia mười số thành hai nửa, mỗi nửa năm số. Trung vị nửa dưới là sáu, trung vị toàn mẫu là bảy và trung vị nửa trên là tám. Ta được bộ ba tứ phân vị sáu, bảy và tám. Ba mốc này chia mẫu theo những vị trí có ý nghĩa.

### Nhóm B: phần giữa rộng hơn
Với nhóm B, năm điểm thấp có trung vị bốn, toàn bộ mẫu vẫn có trung vị bảy, còn năm điểm cao có trung vị mười. Vì vậy nhóm B có tứ phân vị thứ nhất bằng bốn và tứ phân vị thứ ba bằng mười. Mặc dù trung vị trùng với A, một nửa dữ liệu trung tâm của B trải rộng hơn nhiều.

### Dựng hai biểu đồ hộp
Biểu đồ hộp đặt năm mốc nhỏ nhất, tứ phân vị thứ nhất, trung vị, tứ phân vị thứ ba và lớn nhất trên một trục. Với A, hộp từ sáu đến tám nên dài hai đơn vị. Với B, hộp từ bốn đến mười nên dài sáu. Cùng một tỉ lệ trục, hộp B dài hơn rõ rệt.

### So sánh IQR và khoảng biến thiên
Khoảng biến thiên nhóm A bằng chín trừ năm, tức bốn; nhóm B bằng mười trừ bốn, tức sáu. Khoảng tứ phân vị lần lượt bằng hai và sáu. Cả hai tiêu chí đều cho thấy B phân tán hơn. Với cách dựng biểu đồ hộp không có ngoại lệ trong ví dụ này, các râu đến đúng hai cực trị.

## Chương 04. PHƯƠNG SAI VÀ ĐỘ LỆCH CHUẨN

### Vì sao cần độ lệch chuẩn
Khoảng biến thiên chỉ dựa vào hai cực trị, còn IQR dựa vào các tứ phân vị. Độ lệch chuẩn dùng toàn bộ quan sát, qua bình phương độ lệch so với trung bình. Nếu các giá trị thường nằm xa trung bình, độ lệch chuẩn sẽ tăng. Hãy dùng lại hai dãy mười điểm để lượng hóa quan sát trực quan ban đầu.

### Phương sai của nhóm A
Với nhóm A có trung bình bảy, ta lấy từng điểm trừ bảy rồi bình phương. Cộng tất cả mười bình phương độ lệch thu được mười hai. Chia cho cỡ mẫu mười, phương sai bằng một phẩy hai. Đây là công thức phương sai chia cho n trong thống kê mô tả phổ thông.

### Phương sai của nhóm B
Thực hiện đúng quy trình cho nhóm B, tổng bình phương độ lệch bằng năm mươi bốn. Chia cho mười, phương sai bằng năm phẩy bốn. Cả hai nhóm có cùng trung bình bảy nhưng phương sai của B lớn hơn nhiều, vì số điểm nằm xa trung bình xuất hiện thường xuyên hơn.

### Kết luận bằng độ lệch chuẩn
Lấy căn bậc hai của mỗi phương sai, nhóm A có độ lệch chuẩn khoảng một phẩy không chín năm, nhóm B khoảng hai phẩy ba hai bốn. Theo tiêu chí độ đồng đều, A ổn định hơn B trong bộ số liệu này. Chúng ta chỉ đang mô tả mười quan sát của từng nhóm, không khẳng định mọi lớp học tương lai đều như thế.

## Chương 05. SO SÁNH HAI BẢNG SỐ LIỆU GHÉP NHÓM

### Từ dữ liệu thô sang bảng ghép nhóm
Ở các tập trước, chúng ta học bảng tần số ghép nhóm với bốn lớp, trung điểm năm, bảy, chín và mười một. Khi so sánh hai bảng, các khoảng lớp và đơn vị phải tương thích. Bảng A có tần số sáu, mười tám, mười bốn, hai; bảng B có tần số chín, mười chín, ba, chín.

### Hai bảng cùng trung bình ghép nhóm
Thay từng giá trị trong lớp bằng trung điểm và tính trung bình có trọng số. Cả bảng A và bảng B đều có bốn mươi quan sát; cả hai cho trung bình ghép nhóm bảy phẩy sáu. Nhưng hãy quan sát hình dạng histogram: bảng B có nhiều quan sát hơn ở lớp hai đầu, khác rõ với sự tập trung ở các lớp giữa của A.

### Khác biệt ở phương sai ghép nhóm
Tiếp tục tính phương sai từ trung điểm lớp. Với A, kết quả xấp xỉ hai phẩy bốn bốn, còn B xấp xỉ bốn phẩy bốn bốn. Như vậy, theo mô hình đại diện bởi trung điểm, bảng B phân tán hơn A. Đây là phép so sánh dựa trên dữ liệu ghép nhóm, không được trình bày như thể biết chính xác từng điểm gốc.

### Nói rõ giới hạn của ước lượng
Tần số của từng lớp không cho ta biết vị trí thật của mỗi quan sát bên trong lớp. Bởi vậy các trung bình và phương sai vừa tính chỉ là những số đo từ trung điểm lớp. Ta có thể dùng chúng để mô tả, so sánh gần đúng, nhưng không thể khôi phục chắc chắn các tứ phân vị hay độ lệch chuẩn chính xác của dữ liệu thô.

## Chương 06. LỰA CHỌN CHỈ SỐ THEO MỤC TIÊU

### Mục tiêu: nhiều học sinh đạt từ 6
Bây giờ đặt một câu hỏi thực tế hơn: mục tiêu của giáo viên là bao nhiêu học sinh đạt ít nhất sáu điểm? Ở nhóm A, chín trên mười em đạt yêu cầu, tức chín mươi phần trăm. Ở nhóm B, bảy trên mười em đạt, tức bảy mươi phần trăm. Khi mục tiêu là mức đạt, chúng ta cần đếm theo ngưỡng.

### Mục tiêu: số điểm từ 9 trở lên
Nếu mục tiêu chuyển sang tìm học sinh có điểm rất cao, kết luận lại đổi chiều. Nhóm A chỉ có một điểm từ chín trở lên, còn nhóm B có ba điểm. Các tỉ lệ tương ứng là mười và ba mươi phần trăm. Vì vậy một nhóm có độ phân tán lớn hơn không tự động là tốt hay xấu; còn tùy mục đích đánh giá.

### Không chỉ chọn theo một số đo
Có lúc chúng ta quan tâm điểm trung bình, lúc khác quan tâm tỉ lệ đạt chuẩn, mức xuất sắc hoặc tính ổn định. Những mục tiêu khác nhau có thể ưu tiên các nhóm khác nhau. Trước khi so sánh, hãy nói rõ tiêu chí, tính toán đúng rồi mới đưa ra nhận xét có giới hạn, thay vì tuyên bố nhóm A hay B luôn tốt hơn.

### Quy trình ra quyết định
Một bản phân tích thống kê đáng tin cậy thường có ba phần: mục tiêu đánh giá được phát biểu rõ; chỉ số được lựa chọn và tính đúng; kết luận gắn với số liệu cụ thể. Với mười điểm giả lập này, A có độ lệch chuẩn nhỏ hơn và tỉ lệ đạt sáu cao hơn, còn B có nhiều điểm chín và mười hơn.

## Chương 07. GIỚI HẠN CỦA SỐ LIỆU VÀ KẾT LUẬN

### So sánh cần cùng thang đo
Nếu một mẫu ghi điểm kiểm tra trên thang mười còn mẫu kia đo thời gian làm bài bằng phút, các độ lệch chuẩn không cùng đơn vị nên không thể đem so trực tiếp. Ngay cả khi đều là điểm, việc thang điểm hoặc độ khó bài kiểm tra khác nhau cũng có thể khiến so sánh đơn thuần trở nên thiếu công bằng.

### Một giá trị cực đoan thay đổi điều gì
Hãy nghĩ đến một bộ dữ liệu thời gian học, trong đó một quan sát lớn bất thường. Trung bình và đặc biệt phương sai sẽ phản ứng mạnh vì các khoảng cách được bình phương. Trung vị và khoảng tứ phân vị thường bền vững hơn. Chọn chỉ số thích hợp đòi hỏi chúng ta nhận biết hình dạng phân bố và giá trị ngoại lệ.

### Quy mô mẫu và bối cảnh
Ví dụ đang xét chỉ có mười quan sát mỗi nhóm. Số liệu này cho phép mô tả đúng các nhóm đã quan sát, nhưng chưa đủ để kết luận về toàn bộ học sinh trong trường. Muốn suy rộng, chúng ta cần quan tâm cách chọn mẫu, tính đại diện, bối cảnh lớp học và những nguyên nhân khác có thể ảnh hưởng đến kết quả.

### Phát biểu kết luận có căn cứ
Một câu trả lời tốt có thể viết: trong mẫu mười điểm đã cho, hai nhóm cùng trung bình và trung vị bằng bảy, nhưng A có khoảng tứ phân vị và độ lệch chuẩn nhỏ hơn B. Do đó A đồng đều hơn theo hai tiêu chí ấy. Tránh suy ra rằng một phương pháp dạy học gây ra khác biệt khi chưa có thiết kế nghiên cứu phù hợp.

## Chương 08. BÀI TẬP TỔNG HỢP VÀ PHƯƠNG PHÁP

### Đọc đề và kiểm tra dữ liệu
Bài tập tổng hợp cuối video cho hai dãy tám điểm. Hãy sắp xếp chúng, kiểm tra mỗi dãy có đúng tám số và cùng tổng năm mươi sáu. Nhiệm vụ là so sánh trung bình, trung vị, khoảng biến thiên, khoảng tứ phân vị và độ lệch chuẩn, rồi viết một kết luận phù hợp với các kết quả.

### Tính những số đo trung tâm
Vì tổng đều là năm mươi sáu và mỗi mẫu có tám quan sát, trung bình hai nhóm cùng bằng bảy. Trung vị là trung bình cộng vị trí thứ tư và thứ năm, cũng bằng bảy cho cả hai. Như vậy, các số đo trung tâm một lần nữa trùng nhau, nên ta phải chuyển sang độ phân tán để phân biệt.

### So sánh tứ phân vị và phương sai
Với mẫu A, tứ phân vị thứ nhất bằng sáu, thứ ba bằng tám nên khoảng tứ phân vị bằng hai. Với mẫu B, hai tứ phân vị là bốn phẩy năm và chín phẩy năm, khoảng tứ phân vị bằng năm. Tính tiếp phương sai bằng cách chia tổng bình phương độ lệch cho tám, ta được một phẩy năm và năm phẩy năm.

### Viết kết luận và chọn mục tiêu
Lấy căn bậc hai, độ lệch chuẩn A khoảng một phẩy hai hai năm, B khoảng hai phẩy ba bốn năm. Vì hai mẫu có cùng trung bình, cùng trung vị mà A có IQR và độ lệch chuẩn nhỏ hơn, ta kết luận trong mẫu đã cho, A đồng đều hơn. Bài học kết thúc bằng nguyên tắc: chọn chỉ số theo mục tiêu và nêu rõ dữ liệu chứng minh.
