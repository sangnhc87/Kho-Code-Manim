# STAT17 – HƯỚNG DẪN RENDER VÀ NGHIỆM THU

## 1. Nội dung

**Tập:** Tương quan và hồi quy tuyến tính (mở rộng ứng dụng thống kê THPT).

- 8 chương, 32 phân cảnh, thời lượng nền 1216 giây (20:16). Nếu bật giọng đọc, thời lượng có thể tăng theo tốc độ thuyết minh thực tế.
- Bộ số liệu của bài **giả lập**, không dùng để kết luận quan hệ nhân quả.
- Giọng đọc mặc định **nam tiếng Việt**: `vi-VN-NamMinhNeural`.
- Footer hiển thị đúng **Thầy Nguyễn Văn Sang**; **không hiện** số phân cảnh, từ 'nhịp', nhãn debug hoặc công nghệ dựng video.

## 2. Cập nhật repository

Nếu đã có STAT01–16: giải nén `SangMath_ThongKe_STAT17_Patch_GitHubReady.zip` vào gốc repository và commit toàn bộ tệp mới / README đã thay đổi.

Nếu bắt đầu mới: giải nén `SangMath_ThongKe_STAT01_STAT17_GitHubReady.zip` và push lên GitHub.

Không dùng cùng lúc hai ZIP vì cùng chứa STAT17.

## 3. Chạy GitHub Actions

Vào **Actions → Render STAT17 - Tuong quan va Hoi quy tuyen tinh → Run workflow**.

1. Chọn `quality=preview`, `voice=off` để kiểm tra hình và công thức.
2. Workflow chạy unittest → kiểm tra mock 32 trạng thái → biên dịch 8 SVG Typst → chuẩn bị thời lượng và phụ đề → **smoke-render bằng Manim thật** → render MP4.
3. Tải **Artifacts**, duyệt cả 8 hình trích chương và MP4: chữ không đè lên hình; tỉ lệ trục đúng; các đường hồi quy đúng vị trí; chương 7 có điểm ngoại lệ chuyển động.
4. Chạy `voice=on` để kiểm tra giọng **nam**, phát âm các phân số, tiếng Việt và khớp thời lượng với hình.
5. Khi bản xem thử đạt yêu cầu, chạy lại `quality=fullhd`, `voice=on` để xuất 1920×1080, 30 FPS.

**Không xem kiểm thử mô phỏng là thay thế cho render thật.** Video chỉ có thể nghiệm thu sau khi xem MP4 từ workflow.

## 4. Chạy tại môi trường Linux có Manim / Typst

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests
python scripts/build_stat17_typst.py
python scripts/prepare_stat17.py --voice off
python scripts/check_stat17_states.py
manim -ql -r 426,240 --fps 8 stat17/scene.py STAT17_SMOKE
manim -ql -r 854,480 --fps 24 stat17/scene.py STAT17
```

Để thêm giọng nam cần truy cập dịch vụ Edge TTS:

```bash
python scripts/prepare_stat17.py --voice on --voice-id vi-VN-NamMinhNeural
```

Nếu TTS lỗi, workflow phải **báo lỗi** chứ không xuất một video được quảng bá có tiếng nhưng thực tế im lặng.

## 5. Khi build thất bại

| Triệu chứng | Kiểm tra |
|---|---|
| `Typst CLI unavailable` | Setup Typst trên runner; chạy `typst --version`. |
| `STAT17 SVG missing` | Xem bước `build_stat17_typst.py`; bảo đảm 8 SVG hợp lệ trong `assets/stat17_formulas/`. |
| `ModuleNotFoundError` | Chạy `pip install -r requirements.txt` và đứng ở gốc repository. |
| `STAT17 runtime plan invalid` | Chạy lại `prepare_stat17.py`, đảm bảo có đủ 32 entry. |
| MP4 không có âm thanh | Chọn `voice=on`, xem log Edge TTS và stream `ffprobe`. |
| Sai tên, nhãn kỹ thuật | Kiểm tra `stat17/scene.py` và unit test `test_scene_source_clean`. |
| Vỡ bố cục | Tải ảnh trích tám chương, kiểm tra trực quan và sửa khung hình trước khi render Full HD. |
| Cảnh ngoại lệ bị lỗi | Chạy `STAT17_SMOKE`, kiểm tra `ValueTracker` và `always_redraw`. |

## 6. Đáp số chuẩn để rà video

Bộ chính: `(x,y)` lần lượt `(1,2),(2,4),(3,3),(4,5),(5,4),(6,6),(7,7),(8,9)`.

- `x̄ = 4.5`, `ȳ = 5`, `Sxx = 42`, `Sxy = 36`, `Syy = 36`.
- `b = 6/7`, `a = 8/7`; phương trình `ŷ = 8/7 + (6/7)x`.
- `r ≈ 0.925820`, `R² = 6/7 ≈ 0.857143`, `SSE = 36/7 ≈ 5.142857`.
- `ŷ(5) = 38/7 ≈ 5.43`.
- Bài tập cuối: `ŷ = 1 + 2x`, `r=1`.

**Tình trạng môi trường đóng gói:** Đã kiểm tra cú pháp, unittest, mock và tính toàn vẹn ZIP; chưa biên dịch Typst và chưa render MP4 thật do môi trường hiện tại thiếu hai chương trình.
