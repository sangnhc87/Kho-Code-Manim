# STAT17 – BUILD NOTES

Tập STAT17: Tương quan và hồi quy tuyến tính.

**Source of truth:** `stat17/lesson.py`. Mọi giá trị ở đồ thị được suy ra từ `statistics()` và `fitted()`; lời giảng và đáp số kiểm chứng theo dữ liệu gốc.

**Thống kê:** 8 chương, 32 phân cảnh, thời lượng nền 1216 giây (20 phút 16 giây), 8 công thức Typst, 158 đoạn phụ đề ở chế độ không tiếng, 1 cảnh điểm ngoại lệ hoạt họa với `ValueTracker`.

**Nghiệm thu kỹ thuật:** Python compileall; unittest toàn bộ repository; `scripts/check_stat17_states.py`; YAML workflow; kiểm tra integrity ZIP; đối chiếu file cũ; thử patch tái tạo gói trọn bộ. Xem `HUONG_DAN_RENDER_STAT17.md`.

**Hạn chế:** chưa được Manim và Typst biên dịch/render thật trong máy đóng gói. Không coi mã nguồn là MP4 đã được nghiệm thu.

**Chuẩn sản xuất:** giọng nam `vi-VN-NamMinhNeural` nếu có TTS; footer `Thầy Nguyễn Văn Sang`; không hiện số nhịp, nhãn debug hay tên công nghệ trên video.
