# Series Thống kê trực quan – SANGMATH

Dự kiến 18 tập, theo ba khối phổ thông 10–12 và một phần mở rộng.

- STAT01 – Dữ liệu thống kê và bảng tần số: code.
- STAT02 – Các loại biểu đồ: code.
- STAT03 – Trung bình, trung vị, mốt: code.
- STAT04 – Tứ phân vị Q1,Q2,Q3: code.
- STAT05 – Khoảng biến thiên, IQR, biểu đồ hộp: tiếp theo.
- STAT06 – Phương sai, độ lệch chuẩn: dự kiến.
- STAT07–STAT14 – Mẫu số liệu ghép nhóm và vận dụng: dự kiến.
- STAT15–STAT18 – Đọc hiểu biểu đồ, nghịch lý Simpson, tương quan, lấy mẫu: mở rộng.

Cả bốn tập hiện là **mã nguồn GitHub Ready**, chưa phải MP4 Manim được nghiệm thu.
