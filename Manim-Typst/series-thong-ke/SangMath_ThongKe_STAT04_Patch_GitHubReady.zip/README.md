# SangMath – Thống kê trực quan 10–12

Bộ nguồn bao gồm **STAT01–STAT04**. Mã nguồn tách dữ liệu/luận giải khỏi Manim để dễ kiểm thử và tái sử dụng.

## Các video
- STAT01: Dữ liệu biết nói – 40 điểm kiểm tra giả lập.
- STAT02: Các biểu đồ thống kê.
- STAT03: Số trung bình, trung vị và mốt.
- **STAT04: Tứ phân vị Q1, Q2, Q3; mẫu chẵn/lẻ; tần số tích lũy; ngoại lệ; IQR.**

## Dữ liệu STAT04
40 điểm kiểm tra *giả lập* giống ba tập trước, N=40, Q1=6, Q2=7, Q3=8, IQR=2.
Xác định bằng trung vị hai nửa: vị trí 10–11, 20–21, 30–31.

Với n lẻ, bỏ trung vị toàn mẫu trước khi chia thành hai nửa. Đây là quy ước sách giáo khoa phổ thông; phần mềm thống kê có thể sử dụng thuật toán tứ phân vị khác.

## Render
Xem `HUONG_DAN_RENDER_STAT04.md`. Chạy `python -m unittest discover -s tests -v` để kiểm tra toán học.

Cảnh chính: `stat04/scene.py` – class `STAT04`. 32 nhịp, 832 giây nền (13:52). Khi bật TTS dùng `edge-tts` và thời lượng cập nhật theo âm thanh thực tế.

Dự án chưa xác nhận render Manim/Typst tại môi trường soạn. **Bản preview từ GitHub phải được duyệt hình, âm thanh và tốc độ** trước khi sử dụng trong lớp.
