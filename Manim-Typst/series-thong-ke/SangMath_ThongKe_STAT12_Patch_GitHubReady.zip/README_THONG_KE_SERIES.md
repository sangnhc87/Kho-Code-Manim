# SANGMATH — THỐNG KÊ TRỰC QUAN 10–11–12

**Đã có mã nguồn STAT01–STAT12 / dự kiến 18 tập.**

## Danh sách

01. Dữ liệu biết nói
02. Các loại biểu đồ thống kê
03. Trung bình, trung vị, mốt dữ liệu gốc
04. Tứ phân vị mẫu số liệu gốc
05. Khoảng biến thiên, IQR và biểu đồ hộp
06. Phương sai và độ lệch chuẩn
07. Ghép nhóm và bảng tần số
08. Trung bình và mốt mẫu ghép nhóm
09. Trung vị mẫu ghép nhóm
10. **Tứ phân vị mẫu ghép nhóm — mới**
11. Khoảng biến thiên và IQR ghép nhóm
12. **Phương sai và độ lệch chuẩn ghép nhóm — mới**
13. So sánh hai mẫu
14. Bài toán thống kê vận dụng cao
15–18. Mở rộng biểu đồ đánh lừa, nghịch lý Simpson, tương quan, lấy mẫu.

STAT10: nội suy ba tứ phân vị từ tần số tích lũy, đồ thị ogive và bài toán ngược tìm tần số. Dữ liệu 40 điểm giả lập được giữ nhất quán từ đầu Series.

Hướng dẫn chạy: `HUONG_DAN_RENDER_STAT10.md`.


STAT12: so sánh phương sai chính xác dữ liệu gốc với ước lượng từ trung điểm lớp, hai mẫu cùng trung bình và bài toán ngược tần số. Xem HUONG_DAN_RENDER_STAT12.md.
