# STAT12 – Nhật ký kiểm tra

- Cơ sở: bản STAT01–11 CleanVideo đã bỏ toàn bộ nhãn kỹ thuật khỏi video.
- Kết quả chính: `n=40`, trung bình ghép nhóm `7,6`, phương sai `2,44`, độ lệch chuẩn `sqrt(2,44) ≈ 1,562`.
- Trung bình gốc `7,1`, phương sai gốc `2,29`.
- Mẫu B tần số `9–19–3–9`: trung bình cùng `7,6`, phương sai `4,44`.
- Thí nghiệm dữ liệu gốc thay một giá trị 10 bằng 30: phương sai `14,94`; phải ghép lại bảng nếu muốn tính chỉ số ghép nhóm mới.
- Bài toán ngược: tần số `x,8,6,6-x`; trung bình `4,2` dẫn tới `x=2`; phương sai `3,36`.
- Mọi kết luận tính từ trung điểm lớp đều được chú thích là số đo **ước lượng**.
- Lời giảng mặc định giọng nam tiếng Việt và footer `Thầy Nguyễn Văn Sang`.
- Kiểm tra `32/32` trạng thái mô phỏng; kết quả này **không thay thế** render thử Manim thực tế.
