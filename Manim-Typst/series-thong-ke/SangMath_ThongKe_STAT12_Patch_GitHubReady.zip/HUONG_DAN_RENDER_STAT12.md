# STAT12 – Hướng dẫn GitHub Actions

**Bài:** Phương sai và độ lệch chuẩn mẫu số liệu ghép nhóm (lớp 12).

## Quy trình chuẩn

1. Sao chép **nội dung bên trong ZIP**, không thêm một thư mục bọc ngoài, vào repository `sangmath-thong-ke`; commit và push.
2. Mở **Actions → Render STAT12 - Phuong sai va Do lech chuan ghep nhom → Run workflow**.
3. Lượt đầu đặt `quality = preview`, `voice = off`. Hệ thống kiểm thử Python, biên dịch cả tám công thức Typst, tạo timeline, smoke-render toàn bộ 32 trạng thái, rồi mới render MP4 thử ở 854×480.
4. Tải `Artifacts`, xem `STAT12.mp4`, phụ đề SRT, tám ảnh chụp từng chương, báo cáo QA. Kiểm tra kỹ tràn chữ, cột biểu đồ và tính nhất quán kết quả.
5. Khi hình ổn, chạy `voice = on` để dùng giọng **nam giới** `vi-VN-NamMinhNeural`. Workflow sẽ báo lỗi nếu TTS không phát sinh tệp hợp lệ hoặc MP4 không có âm thanh. Đường truyền mạng cần hoạt động.
6. Cuối cùng chọn `quality = fullhd`: 1920×1080, 30 FPS.

## Hiển thị chuẩn dành cho học sinh

- Footer **Thầy Nguyễn Văn Sang**.
- Không hiện nhãn điều phối nội bộ (nhịp, tên Scene, số bước phát hoặc bộ đếm debug).
- Không hiện chữ **Manim–Typst** trên video.
- Mã và tên công nghệ chỉ nằm trong thư mục dự án, không phải nội dung giảng dạy.
- Không xuất đáp số trước khi xuất hiện lập luận tương ứng.

## Lỗi thường gặp

| Biểu hiện | Cách kiểm tra |
|---|---|
| Không tạo được SVG | Xem log bước `Compile all STAT12 Typst formula SVGs`; kiểm tra các tệp `typst/stat12/*.typ`. |
| Sai cảnh hoặc thiếu thư viện | Bước `Smoke-render all 32 complete states` xuất lỗi chi tiết trước render Full HD. |
| MP4 không đủ thời gian | Kiểm tra `stat12/runtime_plan.json`; QA sẽ báo sai thời lượng so với kế hoạch. |
| Bật tiếng nhưng video không có tiếng | Xem log `prepare_stat12.py` và báo cáo QA; thiếu MP3 làm job thất bại. |
| Lệch/đè chữ | Xem tám ảnh trong `artifacts/stat12_qa`; sửa `stat12/scene.py`, render Preview lại. |

## Trạng thái nghiệm thu

Đã kiểm chứng mô hình toán, kiểm thử Python và các trạng thái mô phỏng. **Chưa phải xác nhận render MP4 Manim/Typst thực tế ở môi trường soạn mã.** GitHub Actions phải chạy thành công và bản hình/tiếng phải được duyệt trước khi phát hành.
