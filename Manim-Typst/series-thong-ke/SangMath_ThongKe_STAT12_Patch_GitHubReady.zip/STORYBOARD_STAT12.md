# STORYBOARD STAT12 – 32 phân cảnh trong 8 chương

Footer xuất hiện trên video: **Thầy Nguyễn Văn Sang**. Không hiển thị bộ đếm, mã nội bộ hay tên công nghệ.

Hình được chia hai cột: mô hình bên trái, lập luận và công thức bên phải. Công thức chỉ xuất hiện ở phần cuối mỗi chương.

## Chương 01. VÌ SAO CẦN ĐỘ LỆCH CHUẨN CHO DỮ LIỆU GHÉP NHÓM?

**1. Nhìn lại bảng 40 điểm**
- Nhận xét chính: Bốn nhóm: 6, 18, 14, 2.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**2. Hai lớp học có thể cùng trung bình**
- Nhận xét chính: Cùng một tâm chưa nói hết phân bố.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**3. Dữ liệu đã được ghép nhóm**
- Nhận xét chính: Không còn biết chính xác từng điểm.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**4. Báo trước ý nghĩa xấp xỉ**
- Nhận xét chính: Kết quả ghép nhóm chỉ là ước lượng.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

## Chương 02. TRUNG ĐIỂM LỚP VÀ SỐ TRUNG BÌNH ƯỚC LƯỢNG

**1. Chọn bốn trung điểm**
- Nhận xét chính: m = 5, 7, 9, 11.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**2. Đặt trọng số theo tần số**
- Nhận xét chính: Tổng tần số vẫn là 40.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**3. Tính số trung bình ghép nhóm**
- Nhận xét chính: (6×5 + 18×7 + 14×9 + 2×11)/40.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**4. So với số liệu ban đầu**
- Nhận xét chính: Trung bình gốc 7,1; ghép nhóm 7,6.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

## Chương 03. XÂY DỰNG CÔNG THỨC PHƯƠNG SAI TỪ ĐỘ LỆCH

**1. Đo khoảng cách tới tâm**
- Nhận xét chính: Độ lệch: mᵢ − 7,6.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**2. Bình phương độ lệch**
- Nhận xét chính: Bình phương làm mọi đóng góp không âm.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**3. Cân bằng mỗi lớp theo tần số**
- Nhận xét chính: Nhân bình phương độ lệch với tần số.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**4. Kết quả phương sai và căn bậc hai**
- Nhận xét chính: Phương sai ≈ 2,44; độ lệch chuẩn ≈ 1,562.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

## Chương 04. CÔNG THỨC RÚT GỌN VÀ KIỂM CHỨNG

**1. Một con đường tính khác**
- Nhận xét chính: Dùng bình phương trung điểm lớp.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**2. Tính trung bình bình phương**
- Nhận xét chính: Tổng có trọng số là 2408.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**3. Trừ bình phương trung bình**
- Nhận xét chính: 60,2 − 7,6² = 2,44.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**4. Nhớ căn bậc hai ở bước cuối**
- Nhận xét chính: Độ lệch chuẩn dùng cùng đơn vị dữ liệu.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

## Chương 05. CÙNG TRUNG BÌNH, KHÁC ĐỘ PHÂN TÁN

**1. Tạo bảng thứ hai cùng trung bình**
- Nhận xét chính: Tần số mới: 9, 19, 3, 9.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**2. Giữ nguyên vạch trung bình**
- Nhận xét chính: Hai vạch trung bình đều ở 7,6.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**3. So sánh hai phương sai**
- Nhận xét chính: A: 2,44; B: 4,44.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**4. So sánh độ lệch chuẩn**
- Nhận xét chính: A: 1,562; B: 2,107.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

## Chương 06. ĐƠN VỊ ĐO, PHÉP BIẾN ĐỔI VÀ CÔNG THỨC THƯỜNG NHẦM

**1. Cộng một hằng số vào toàn bộ điểm**
- Nhận xét chính: Phương sai và độ lệch chuẩn không đổi.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**2. Nhân mọi giá trị với hai**
- Nhận xét chính: Phương sai nhân 4; độ lệch chuẩn nhân 2.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**3. Vì sao ở THPT chia cho n?**
- Nhận xét chính: Dùng n, không tự đổi thành n − 1.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**4. Không nhầm phương sai với độ lệch chuẩn**
- Nhận xét chính: s² và s có đơn vị khác nhau.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

## Chương 07. NGOẠI LỆ VÀ GIỚI HẠN CỦA MẪU GHÉP NHÓM

**1. Ngoại lệ xuất hiện trên dữ liệu gốc**
- Nhận xét chính: Thay một điểm 10 bằng 30.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**2. Tính lại phương sai từ dữ liệu gốc**
- Nhận xét chính: Phương sai gốc: 2,29 → 14,94.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**3. Không được giữ bảng lớp cũ**
- Nhận xét chính: Nếu có điểm 30 phải ghép nhóm lại.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**4. Dữ liệu ghép nhóm luôn mất chi tiết**
- Nhận xét chính: Hai bộ dữ liệu gốc có thể cùng bảng.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

## Chương 08. VẬN DỤNG: TÌM TẦN SỐ CHƯA BIẾT

**1. Đề bài ngược có bốn lớp**
- Nhận xét chính: [0;2), [2;4), [4;6), [6;8).
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**2. Tìm ẩn từ số trung bình**
- Nhận xét chính: (96 − 6x)/20 = 4,2.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**3. Tính độ phân tán sau khi tìm x**
- Nhận xét chính: Tần số: 2, 8, 6, 4.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.

**4. Tổng kết hai cách tính phương sai**
- Nhận xét chính: Xác định lớp → trung điểm → trung bình → phương sai.
- Hình: biểu đồ/cột/trục số thay đổi theo dữ liệu; kết luận chỉ hiện khi đã giải thích.
