# SANGMATH – THỐNG KÊ TRỰC QUAN

Lộ trình 18 tập, từ thống kê THPT đến những ứng dụng và nghịch lý thống kê.

- STAT01: Dữ liệu thống kê và thu thập dữ liệu
- STAT02: Các loại biểu đồ thống kê
- STAT03: Số trung bình, trung vị, mốt
- STAT04: Tứ phân vị của mẫu không ghép nhóm
- STAT05: Khoảng biến thiên, IQR và box plot
- STAT06: Phương sai, độ lệch chuẩn
- STAT07: Ghép nhóm và bảng tần số
- STAT08: Số trung bình và mốt ghép nhóm
- **STAT09: Trung vị của mẫu số liệu ghép nhóm**
- STAT10: Tứ phân vị của mẫu ghép nhóm
- STAT11–18: phân tán dữ liệu ghép nhóm, so sánh mẫu, vận dụng, đồ thị đánh lừa, nghịch lý Simpson, hồi quy và lấy mẫu.

Tất cả bài giảng dùng dữ liệu mô phỏng rõ nguồn; không nhầm số nội suy ghép nhóm với dữ liệu gốc.
