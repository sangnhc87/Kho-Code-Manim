# SangMath – Thống kê trực quan 10–11–12

Hiện có mã nguồn **STAT01–STAT09** theo Series 18 video Manim–Typst.

- `stat01` … `stat09`: mã bài học và cảnh Manim.
- `typst/stat09/`: tám công thức Typst dùng cho tập 09.
- `scripts/build_stat09_typst.py`, `prepare_stat09.py`, `check_stat09_states.py`, `qa_stat09.py`: công cụ chuẩn bị, kiểm thử và nghiệm thu.
- `.github/workflows/render-stat09.yml`: chọn preview/fullhd, voice on/off.
- `LOI_GIANG_STAT09.md`: 32 nhịp giảng tiếng Việt.
- `STORYBOARD_STAT09.md`, `preview/stat09/`: bảng storyboard xem trước; không phải khung hình MP4.
- `HUONG_DAN_RENDER_STAT09.md`, `BUILD_NOTES_STAT09.md`: cách build và xử lý lỗi.

Chạy `python -m unittest discover -s tests -v` trước khi push. Sau đó làm theo `HUONG_DAN_RENDER_STAT09.md`.

**Lưu ý:** Không tự khẳng định có video Manim hoàn chỉnh trước khi bản MP4 được render và duyệt trên GitHub.
