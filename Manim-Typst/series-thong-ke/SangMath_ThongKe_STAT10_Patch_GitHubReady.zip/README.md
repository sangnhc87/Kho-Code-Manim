# SangMath Thống kê — GitHub Ready (STAT01–STAT10)

Repository Manim + Typst + Python cho 10 tập đầu của Series Thống kê 10–11–12. Tập mới: **STAT10 – Tứ phân vị của mẫu số liệu ghép nhóm**.

- Manim: `stat10/scene.py` → Scenes `STAT10`, `STAT10_SMOKE`.
- Lời giảng/dữ liệu: `stat10/lesson.py`, `LOI_GIANG_STAT10.md`.
- Công thức: `typst/stat10/*.typ` → `assets/stat10_formulas/*.svg` (biên dịch trong Actions).
- Thuyết minh và phụ đề: `scripts/prepare_stat10.py`, `STAT10_vi.srt`.
- Workflow: `.github/workflows/render-stat10.yml`.
- Kiểm thử: `python -m unittest discover -s tests -v`.
- Storyboard: `preview/stat10/STAT10_storyboard_8_chapters.png`.

**Render:** vào GitHub Actions → `Render STAT10 - Tu phan vi mau ghep nhom` → preview/voice-off trước. Xem `HUONG_DAN_RENDER_STAT10.md`.

Không đồng nhất tứ phân vị ghép nhóm (ước lượng) với dữ liệu gốc. Bản này cần render và duyệt MP4 thật trên GitHub Actions; kiểm thử mô phỏng không thay được nghiệm thu hình ảnh.
