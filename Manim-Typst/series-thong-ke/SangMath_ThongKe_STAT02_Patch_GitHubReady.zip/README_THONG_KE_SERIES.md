# SANGMATH – THỐNG KÊ TRỰC QUAN 10–11–12

## Trạng thái

| Tập | Tên | Tình trạng |
|---|---|---|
| STAT01 | Dữ liệu biết nói – 40 điểm kiểm tra | Có code Manim–Typst và workflow; chưa nghiệm thu MP4 thực tế |
| STAT02 | Các loại biểu đồ thống kê | Có code Manim–Typst, 8 chương/32 nhịp và workflow; chưa nghiệm thu MP4 thực tế |
| STAT03 | Số trung bình, trung vị, mốt | Đang trong lộ trình, chưa có mã nguồn |

## Bộ dữ liệu xuyên suốt

STAT01 và STAT02 dùng **cùng 40 điểm kiểm tra giả lập** trong `stat01/lesson.py`. Tại `stat02/lesson.py`, mô đun import chính SCORES và FREQUENCY từ STAT01, không duy trì bản dữ liệu thứ hai. Các tập sau nên tiếp tục kế thừa mô đun này.

Để dạy **loại biểu đồ phù hợp**, STAT02 còn dùng dữ liệu lớp B giả lập 50 học sinh, số liệu liên tục về thời gian di chuyển và một chuỗi số trung bình theo sáu tháng. Mỗi nguồn đều được ghi rõ ràng là **ví dụ độc lập**, không kết luận đó là dữ liệu của lớp A.

## Nguyên tắc đồ họa

- Nền xanh đen, chữ Việt Noto Sans, công thức Typst SVG và hình động Manim.
- Chiều cao biểu đồ cột tần số bắt đầu từ 0; đọc trục và đơn vị trước khi kết luận.
- Biểu đồ tròn: góc và diện tích mỗi lát tỉ lệ với tần số tương đối.
- Histogram: các khoảng kề nhau không có khoảng trống. Với độ rộng lớp không đều, **mật độ** là chiều cao và **diện tích** tương ứng tần số.
- Biểu đồ đường: chỉ dùng khi trình tự diễn tiến có ý nghĩa, chẳng hạn các mốc thời gian.
- Lời đọc chia đúng 32 nhịp; lịch render base **736 giây (12:16)**, có thể tăng khi TTS dài hơn.

## Cấu trúc mới

- `stat01/`, `stat02/`: code và dữ liệu từng tập.
- `.github/workflows/render-stat01.yml`, `render-stat02.yml`: hai workflow riêng, không xung đột.
- `scripts/prepare_stat02.py`: lập timeline, tạo giọng đọc tùy chọn, phụ đề SRT.
- `scripts/build_stat02_typst.py`: biên dịch 6 biểu thức SVG vector.
- `scripts/qa_stat02.py`: kiểm tra MP4, kích thước khung hình, tiếng và ảnh QA theo chương.
- `tests/test_stat02.py`: kiểm thử tần số, góc, histogram, phần trăm, điều kiện kịch bản.
- `preview/stat02/`: 8 ảnh storyboard chương và bảng ghép tổng quan; **không phải** ảnh render thật.

[Hướng dẫn render STAT02](HUONG_DAN_RENDER_STAT02.md).
